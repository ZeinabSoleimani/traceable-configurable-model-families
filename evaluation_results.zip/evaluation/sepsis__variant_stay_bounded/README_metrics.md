# Evidence-CPT evaluation outputs

Recommended paper-level metrics:

1. **Fitness / coverage**: `train_coverage`, `test_coverage`, and `coverage_gap_train_minus_test`.
   If `coverage_mode=bounded`, coverage is bounded by `max_loop_depth` and should be reported as bounded replay coverage.
2. **Precision proxy**: `mean_*_df_precision_proxy`; this is bounded directly-follows precision from enumerated model language.
   For large logs, use `--skip-df-proxy` and report C-DFG relation statistics instead.
3. **Generalization**: primarily `test_coverage`; report across repeated stratified splits.
4. **Simplicity**: `family_nodes`, `family_visible_leaves`, `family_operator_nodes`, `family_max_depth`.
5. **Consolidation**: `compactness_gain_vs_separate_im` and proposed `shared_node_ratio`.
6. **Variant explainability**: C-DFG shared / variant-specific / dominant relation counts in `cdfg_metrics.csv`.
7. **Differential localization**: residual-localization precision/recall/F1 when construction mode is `anchor_localization`.
8. **Scalability**: `runtime_sec` and model size over increasing log sizes.

Baselines included:

- `pooled_im`: one model from the union log.
- `separate_im`: one model per variant.
- `separate_exact`: optional memorization upper-bound; use only for small logs or sanity checks.

## Mean summary by method
| method | mean train coverage | mean test coverage | mean nodes | mean runtime sec |
|---|---:|---:|---:|---:|
| pooled_im | 0.093 | 0.092 | 36.0 | 0.014 |
| proposed_cpt | 0.706 | 0.694 | 108.3 | 0.576 |
| separate_im | 0.093 | 0.092 | 72.0 | 0.014 |

## C-DFG rows

Total C-DFG result rows: 3
