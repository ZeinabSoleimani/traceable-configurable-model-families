# Lightweight Experiment Results Bundle

This bundle contains lightweight, review-friendly experiment outputs extracted from the uploaded result folders.

Included:
- SVG renderings
- DOT graph files
- JSON metadata / configured trees / residual fragments
- CSV relation-level data
- TXT construction summaries

Excluded:
- PNG renderings, because equivalent SVG files are much smaller and suitable for GitHub review.
- LOG files, because they contained local cluster paths and user identifiers.
- __MACOSX files, because they are macOS resource-fork metadata and not part of the artifact.

Recommended use:
- Commit this lightweight bundle to the GitHub artifact repository under `results/`.
- Keep full raw output folders outside Git history, e.g., as a GitHub Release asset, Zenodo/OSF record, or regenerate them using scripts.

