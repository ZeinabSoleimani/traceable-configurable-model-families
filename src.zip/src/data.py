from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import csv
from pathlib import Path
from typing import Iterable, Mapping, Sequence

Trace = tuple[str, ...]


@dataclass(frozen=True)
class Case:
    """One case in a variant-labeled event log."""

    case_id: str
    variant: str
    trace: Trace

    def __post_init__(self) -> None:
        if not self.case_id:
            raise ValueError("case_id must not be empty")
        if not self.variant:
            raise ValueError("variant must not be empty")
        if not isinstance(self.trace, tuple):
            object.__setattr__(self, "trace", tuple(self.trace))


@dataclass(frozen=True)
class VariantLog:
    """A finite variant-labeled event log.

    The log is represented at trace level. Event-level CSV input can be converted
    with :meth:`from_event_csv`.
    """

    cases: tuple[Case, ...]

    def __post_init__(self) -> None:
        if not self.cases:
            raise ValueError("VariantLog must contain at least one case")
        ids = [case.case_id for case in self.cases]
        if len(ids) != len(set(ids)):
            raise ValueError("case_id values must be unique")

    @classmethod
    def from_rows(
        cls,
        rows: Iterable[Mapping[str, object] | tuple[str, str, Sequence[str] | str]],
        *,
        case_key: str = "case_id",
        variant_key: str = "variant",
        trace_key: str = "trace",
        trace_sep: str = ",",
    ) -> "VariantLog":
        cases: list[Case] = []
        for row in rows:
            if isinstance(row, Mapping):
                case_id = str(row[case_key]).strip()
                variant = str(row[variant_key]).strip()
                trace_raw = row[trace_key]
            else:
                case_id, variant, trace_raw = row
                case_id = str(case_id).strip()
                variant = str(variant).strip()
            trace = _parse_trace(trace_raw, trace_sep=trace_sep)
            cases.append(Case(case_id=case_id, variant=variant, trace=trace))
        return cls(tuple(cases))

    @classmethod
    def from_trace_csv(
        cls,
        path: str | Path,
        *,
        case_col: str = "case_id",
        variant_col: str = "variant",
        trace_col: str = "trace",
        trace_sep: str = ",",
    ) -> "VariantLog":
        with Path(path).open(newline="", encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            return cls.from_rows(
                reader,
                case_key=case_col,
                variant_key=variant_col,
                trace_key=trace_col,
                trace_sep=trace_sep,
            )

    @classmethod
    def from_event_csv(
        cls,
        path: str | Path,
        *,
        case_col: str = "case_id",
        variant_col: str = "variant",
        activity_col: str = "activity",
        timestamp_col: str | None = "timestamp",
    ) -> "VariantLog":
        rows: list[dict[str, str]] = []
        with Path(path).open(newline="", encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                rows.append(row)
        if timestamp_col and timestamp_col in (rows[0].keys() if rows else []):
            rows.sort(key=lambda r: (r[case_col], r[timestamp_col]))
        else:
            rows.sort(key=lambda r: r[case_col])

        variants: dict[str, str] = {}
        traces: dict[str, list[str]] = defaultdict(list)
        for row in rows:
            cid = str(row[case_col]).strip()
            variant = str(row[variant_col]).strip()
            activity = str(row[activity_col]).strip()
            if not activity:
                continue
            if cid in variants and variants[cid] != variant:
                raise ValueError(f"case {cid!r} has more than one variant label")
            variants[cid] = variant
            traces[cid].append(activity)
        cases = [Case(cid, variants[cid], tuple(trace)) for cid, trace in traces.items()]
        return cls(tuple(cases))

    @property
    def variants(self) -> tuple[str, ...]:
        return tuple(sorted({case.variant for case in self.cases}))

    @property
    def activities(self) -> frozenset[str]:
        return frozenset(activity for case in self.cases for activity in case.trace)

    def sublog(self, variant: str) -> list[Trace]:
        return [case.trace for case in self.cases if case.variant == variant]

    def all_traces(self) -> list[Trace]:
        return [case.trace for case in self.cases]

    def activity_counts(self, variant: str | None = None) -> Counter[str]:
        counter: Counter[str] = Counter()
        for case in self.cases:
            if variant is None or case.variant == variant:
                counter.update(case.trace)
        return counter

    def activity_sets_by_variant(self) -> dict[str, frozenset[str]]:
        return {
            variant: frozenset(self.activity_counts(variant).keys())
            for variant in self.variants
        }

    def common_activities(self) -> frozenset[str]:
        sets = list(self.activity_sets_by_variant().values())
        if not sets:
            return frozenset()
        return frozenset.intersection(*sets)

    def projected_traces(
        self,
        activities: set[str] | frozenset[str],
        *,
        collapse_consecutive: bool = False,
    ) -> list[Trace]:
        projected: list[Trace] = []
        for case in self.cases:
            trace = tuple(a for a in case.trace if a in activities)
            if collapse_consecutive:
                trace = collapse_consecutive_duplicates(trace)
            projected.append(trace)
        return projected

    def to_trace_csv(
        self,
        path: str | Path,
        *,
        trace_sep: str = ",",
    ) -> None:
        with Path(path).open("w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=["case_id", "variant", "trace"])
            writer.writeheader()
            for case in self.cases:
                writer.writerow(
                    {
                        "case_id": case.case_id,
                        "variant": case.variant,
                        "trace": trace_sep.join(case.trace),
                    }
                )


def _parse_trace(value: object, *, trace_sep: str) -> Trace:
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return tuple()
        # Accept either "A,B,C" or "<A,B,C>".
        text = text.strip("<>")
        parts = [part.strip() for part in text.split(trace_sep)]
        return tuple(part for part in parts if part)
    return tuple(str(x).strip() for x in value if str(x).strip())


def collapse_consecutive_duplicates(trace: Sequence[str]) -> Trace:
    collapsed: list[str] = []
    sentinel = object()
    prev: object | str = sentinel
    for activity in trace:
        if activity != prev:
            collapsed.append(activity)
        prev = activity
    return tuple(collapsed)


def depression_example_log() -> VariantLog:
    """Return the motivating TRD/nTRD example from the paper text."""

    rows = [
        ("P01", "TRD", ("A", "B", "C", "P", "M", "Q", "C", "D", "E")),
        ("P02", "TRD", ("A", "B", "C", "M", "P", "Q", "C", "D", "E")),
        ("P03", "TRD", ("A", "B", "C", "P", "M", "C", "D", "E")),
        ("P04", "TRD", ("A", "B", "C", "P", "M", "Q", "C", "P", "M", "Q", "C", "D", "E")),
        ("P05", "TRD", ("A", "B", "C", "M", "P", "C", "P", "M", "C", "D", "E")),
        ("P06", "nTRD", ("A", "B", "C", "D", "W", "E")),
        ("P07", "nTRD", ("A", "B", "S", "C", "D", "E")),
        ("P08", "nTRD", ("A", "B", "S", "T", "C", "D", "E")),
        ("P09", "nTRD", ("A", "B", "C", "D", "E")),
        ("P10", "nTRD", ("A", "B", "S", "C", "D", "W", "E")),
        ("P11", "nTRD", ("A", "B", "C", "D", "E")),
    ]
    return VariantLog.from_rows(rows)
