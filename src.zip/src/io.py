from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Any

from .enrichment import EnrichmentResult
from .viz import cdfg_to_dot, process_tree_to_dot


def write_result(
    result: EnrichmentResult,
    out_dir: str | Path,
    render_visuals: bool = True,
    cdfg_core_min_support: float = 0.10,
    cdfg_core_min_support_delta: float = 0.05,
    cdfg_core_min_support_by_variant: dict[str, float] | None = None,
    cdfg_core_dominance_only: bool = False,
    cpst_hide_trivial_tau: bool = True,
    cpst_tiny_support_threshold: float = 0.01,
    write_cpst_core: bool = True,
) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    construction_metadata = {
        "construction_mode": result.construction_mode,
        "construction_note": result.construction_note,
        "used_fallback_legacy": result.used_fallback,
        "shared_activities": sorted(result.shared_activities),
        "shared_context_available": result.shared_context is not None,
        "residual_fragment_count": len(result.fragments),
        "cpst_visualization": {
            "default_hides_trivial_tau": cpst_hide_trivial_tau,
            "tiny_support_threshold": cpst_tiny_support_threshold,
            "core_cpst_written": write_cpst_core,
            "note": "visualization settings do not change configurable_tree.json",
        },
    }
    (out / "construction_metadata.json").write_text(
        json.dumps(construction_metadata, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    (out / "construction_summary.txt").write_text(
        "construction_mode: " + result.construction_mode + "\n"
        + "construction_note: " + (result.construction_note or "<none>") + "\n"
        + "used_fallback_legacy: " + str(result.used_fallback) + "\n"
        + "residual_fragment_count: " + str(len(result.fragments)) + "\n",
        encoding="utf-8",
    )

    # CDFG evidence table and visualization
    result.cdfg.to_csv(out / "cdfg.csv")

    # Full CDFG: keeps all retained relations.
    # Useful as the complete evidence artifact, but can be visually dense.
    (out / "cdfg.dot").write_text(
        result.cdfg.to_dot(
            colored=True,
            show_supports=False,
            title="Full Configurable Directly-Follows Graph (CDFG)",
            view_note="Full CDFG: complete method-retained evidence view",
            show_no_filter_note=True,
        ),
        encoding="utf-8",
    )

    (out / "cdfg_with_supports.dot").write_text(
        result.cdfg.to_dot(
            colored=True,
            show_supports=True,
            tiny_support_threshold=cpst_tiny_support_threshold,
            title="Full CDFG with Support Values",
            view_note="Full CDFG with supports: complete method-retained evidence view",
            show_no_filter_note=True,
        ),
        encoding="utf-8",
    )

    # Core CDFG: filtered visualization for inspection/paper figures.
    # The underlying evidence in cdfg.csv is unchanged.
    (out / "cdfg_core.dot").write_text(
        result.cdfg.to_dot(
            colored=True,
            show_supports=False,
            min_support=cdfg_core_min_support,
            min_support_delta=cdfg_core_min_support_delta,
            min_support_by_variant=cdfg_core_min_support_by_variant,
            dominance_only=cdfg_core_dominance_only,
            keep_lifecycle_edges=True,
            title="Core CDFG (Filtered Visualization)",
            view_note="Core CDFG: method-retained evidence plus visualization filter",
        ),
        encoding="utf-8",
    )

    (out / "cdfg_core_with_supports.dot").write_text(
        result.cdfg.to_dot(
            colored=True,
            show_supports=True,
            tiny_support_threshold=cpst_tiny_support_threshold,
            min_support=cdfg_core_min_support,
            min_support_delta=cdfg_core_min_support_delta,
            min_support_by_variant=cdfg_core_min_support_by_variant,
            dominance_only=cdfg_core_dominance_only,
            keep_lifecycle_edges=True,
            title="Core CDFG with Support Values (Filtered Visualization)",
            view_note="Core CDFG with supports: method-retained evidence plus visualization filter",
        ),
        encoding="utf-8",
    )

    # Shared context
    (out / "shared_context.txt").write_text(
        result.shared_context.to_text() if result.shared_context else "<no shared context mined; structure-first merge used>",
        encoding="utf-8",
    )
    if result.shared_context:
        (out / "shared_context_full.dot").write_text(
            process_tree_to_dot(
                result.shared_context,
                title="Shared Process-Tree Context (Full Visualization)",
                cdfg=result.cdfg,
                activity_supports=result.activity_supports,
                hide_trivial_tau=False,
                tiny_support_threshold=cpst_tiny_support_threshold,
            ),
            encoding="utf-8",
        )
        (out / "shared_context.dot").write_text(
            process_tree_to_dot(
                result.shared_context,
                title="Shared Process-Tree Context",
                cdfg=result.cdfg,
                activity_supports=result.activity_supports,
                hide_trivial_tau=cpst_hide_trivial_tau,
                tiny_support_threshold=cpst_tiny_support_threshold,
            ),
            encoding="utf-8",
        )

    # Configurable process tree
    (out / "configurable_tree.txt").write_text(result.tree.to_text(), encoding="utf-8")
    (out / "configurable_tree.json").write_text(result.tree.to_json(), encoding="utf-8")
    (out / "configurable_tree_full.dot").write_text(
        process_tree_to_dot(
            result.tree,
            title=f"Configurable Process Tree (CPST) — full view — {result.construction_mode}",
            cdfg=result.cdfg,
            activity_supports=result.activity_supports,
            hide_trivial_tau=False,
            tiny_support_threshold=cpst_tiny_support_threshold,
        ),
        encoding="utf-8",
    )
    (out / "configurable_tree.dot").write_text(
        process_tree_to_dot(
            result.tree,
            title=f"Configurable Process Tree (CPST) — cleaned view — {result.construction_mode}",
            cdfg=result.cdfg,
            activity_supports=result.activity_supports,
            hide_trivial_tau=cpst_hide_trivial_tau,
            tiny_support_threshold=cpst_tiny_support_threshold,
        ),
        encoding="utf-8",
    )
    if write_cpst_core:
        (out / "configurable_tree_core.dot").write_text(
            process_tree_to_dot(
                result.tree,
                title=f"Core Configurable Process Tree (CPST) — {result.construction_mode}",
                cdfg=result.cdfg,
                activity_supports=result.activity_supports,
                hide_trivial_tau=True,
                compact=True,
                tiny_support_threshold=cpst_tiny_support_threshold,
            ),
            encoding="utf-8",
        )

    # Configured variant views
    for variant, tree in result.configured_trees().items():
        safe = _safe_filename(variant)
        (out / f"configured_{safe}.txt").write_text(tree.to_text(), encoding="utf-8")
        (out / f"configured_{safe}.json").write_text(tree.to_json(), encoding="utf-8")
        (out / f"configured_{safe}_full.dot").write_text(
            process_tree_to_dot(
                tree,
                title=f"Configured View: {variant} (Full Visualization)",
                cdfg=result.cdfg,
                activity_supports=result.activity_supports,
                hide_trivial_tau=False,
                tiny_support_threshold=cpst_tiny_support_threshold,
            ),
            encoding="utf-8",
        )
        (out / f"configured_{safe}.dot").write_text(
            process_tree_to_dot(
                tree,
                title=f"Configured View: {variant}",
                cdfg=result.cdfg,
                activity_supports=result.activity_supports,
                hide_trivial_tau=cpst_hide_trivial_tau,
                tiny_support_threshold=cpst_tiny_support_threshold,
            ),
            encoding="utf-8",
        )

    fragments: list[dict[str, Any]] = []
    for fragment in result.fragments:
        fragments.append(
            {
                "variant": fragment.variant,
                "gap": fragment.gap,
                "log": [list(trace) for trace in fragment.log],
                "tree": fragment.tree.to_dict(),
            }
        )

    (out / "residual_fragments.json").write_text(
        json.dumps(fragments, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    if render_visuals:
        _render_dot_files(out)


def _render_dot_files(out: Path) -> None:
    dot = shutil.which("dot")
    if dot is None:
        (out / "visualization_note.txt").write_text(
            "Graphviz 'dot' was not found, so PNG/SVG files were not generated.\n"
            "On Minerva, try: module load graphviz\n",
            encoding="utf-8",
        )
        return

    for dot_file in sorted(out.glob("*.dot")):
        for fmt in ("svg", "png"):
            output = dot_file.with_suffix(f".{fmt}")
            cmd = [dot, f"-T{fmt}", str(dot_file), "-o", str(output)]
            if fmt == "png":
                # Higher DPI improves readability in papers/LaTeX without
                # changing the DOT structure. SVG output remains vector-based.
                cmd.insert(2, "-Gdpi=300")

            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            if proc.returncode != 0:
                (out / f"{dot_file.stem}_{fmt}_render_error.txt").write_text(
                    proc.stderr,
                    encoding="utf-8",
                )


def _safe_filename(value: str) -> str:
    return "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in value)
