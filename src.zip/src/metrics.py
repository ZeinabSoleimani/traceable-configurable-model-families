from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Sequence

from .cdfg import Relation, directly_follows_counts
from .data import Trace, VariantLog
from .enrichment import EnrichmentResult
from .ptree import ProcessTree


@dataclass(frozen=True)
class CoverageReport:
    variant: str
    covered: int
    total: int

    @property
    def fitness_proxy(self) -> float:
        return self.covered / self.total if self.total else 1.0


@dataclass(frozen=True)
class LocalizationReport:
    true_positive: int
    false_positive: int
    false_negative: int

    @property
    def precision(self) -> float:
        denom = self.true_positive + self.false_positive
        return self.true_positive / denom if denom else 1.0

    @property
    def recall(self) -> float:
        denom = self.true_positive + self.false_negative
        return self.true_positive / denom if denom else 1.0

    @property
    def f1(self) -> float:
        p = self.precision
        r = self.recall
        return 2 * p * r / (p + r) if p + r else 0.0


def observed_trace_coverage(log: VariantLog, tree: ProcessTree, *, max_loop_depth: int = 3) -> list[CoverageReport]:
    reports: list[CoverageReport] = []
    for variant in log.variants:
        configured = tree.project(variant)
        traces = log.sublog(variant)
        covered = sum(
            1 for trace in traces if configured.accepts_observed_trace(trace, max_loop_depth=max_loop_depth)
        )
        reports.append(CoverageReport(variant=variant, covered=covered, total=len(traces)))
    return reports


def residual_relation_localization(result: EnrichmentResult) -> LocalizationReport:
    """Compare localized residual directly-follows relations with CDFG differential relations.

    This is a lightweight counterpart of the paper's differential-relation
    localization measure. It compares relations produced inside residual
    fragment logs to the CDFG's differential relation set.
    """

    predicted: set[Relation] = set()
    for fragment in result.fragments:
        counts, _ = directly_follows_counts(list(fragment.log))
        predicted.update(counts.keys())
    gold = set(result.cdfg.differential_relations())
    return LocalizationReport(
        true_positive=len(predicted & gold),
        false_positive=len(predicted - gold),
        false_negative=len(gold - predicted),
    )
