from __future__ import annotations

from dataclasses import dataclass
from math import erf, sqrt
from typing import Iterable


@dataclass(frozen=True)
class ProportionTest:
    first: str
    second: str
    support_first: float
    support_second: float
    z: float
    p_value: float
    adjusted_p_value: float | None = None
    significant: bool = False


def normal_cdf(x: float) -> float:
    return 0.5 * (1.0 + erf(x / sqrt(2.0)))


def two_proportion_z_test(x1: int, n1: int, x2: int, n2: int) -> tuple[float, float]:
    """Return z statistic and two-sided p-value for two proportions.

    The implementation has no scipy dependency. It uses the standard pooled
    variance form and returns ``(0, 1)`` when the variance is degenerate.
    """

    if n1 <= 0 or n2 <= 0:
        return 0.0, 1.0
    p1 = x1 / n1
    p2 = x2 / n2
    pooled = (x1 + x2) / (n1 + n2)
    variance = pooled * (1.0 - pooled) * (1.0 / n1 + 1.0 / n2)
    if variance <= 0.0:
        return 0.0, 1.0
    z = (p1 - p2) / sqrt(variance)
    p_value = 2.0 * (1.0 - normal_cdf(abs(z)))
    return z, max(0.0, min(1.0, p_value))


def benjamini_hochberg(p_values: Iterable[float], alpha: float) -> tuple[list[bool], list[float]]:
    """Benjamini-Hochberg FDR correction.

    Returns a tuple ``(significant, adjusted_p_values)`` in the original order.
    """

    p = [max(0.0, min(1.0, float(value))) for value in p_values]
    m = len(p)
    if m == 0:
        return [], []

    order = sorted(range(m), key=lambda i: p[i])
    significant = [False] * m
    threshold_rank = -1
    for rank, i in enumerate(order, start=1):
        if p[i] <= alpha * rank / m:
            threshold_rank = rank
    if threshold_rank > 0:
        cutoff = alpha * threshold_rank / m
        significant = [value <= cutoff for value in p]

    adjusted = [1.0] * m
    running_min = 1.0
    for rank_from_end, i in enumerate(reversed(order), start=1):
        rank = m - rank_from_end + 1
        running_min = min(running_min, p[i] * m / rank)
        adjusted[i] = max(0.0, min(1.0, running_min))
    return significant, adjusted
