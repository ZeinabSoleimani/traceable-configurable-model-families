from __future__ import annotations

import itertools

FILL_COLORS = [
    "#D9E8FF",  # blue
    "#FFE2C2",  # orange
    "#D8F3DC",  # green
    "#FADADD",  # red/pink
    "#E6D9FF",  # purple
    "#FFF2B2",  # yellow
    "#E6CCB2",  # brown
    "#D9F0F2",  # cyan
]

BORDER_COLORS = [
    "#2F6BBA",
    "#C96A00",
    "#2B8A3E",
    "#C92A2A",
    "#7048A8",
    "#A88700",
    "#8B5E34",
    "#0B7285",
]

OPERATOR_SYMBOLS = {
    "seq": "→",
    "xor": "×",
    "and": "∧",
    "loop": "↺",
}


def cdfg_to_dot(cdfg, show_supports: bool = False) -> str:
    """Colored DOT visualization for the Configurable Directly-Follows Graph."""
    return cdfg.to_dot(colored=True, show_supports=show_supports)


def process_tree_to_dot(
    tree,
    title: str = "Configurable Process Tree",
    *,
    cdfg=None,
    activity_supports=None,
    show_arc_evidence: bool = True,
    hide_trivial_tau: bool = True,
    compact: bool = False,
    tiny_support_threshold: float = 0.01,
) -> str:
    """Colored DOT visualization for configurable process trees.

    Node colors encode CPST structural activation/availability. Edge labels
    are evidence overlays: single-activity arcs report per-variant case-level
    support. Relation-level dominance remains available in the CDFG outputs and
    is not repeated on CPST activity labels or structural arcs.

    ``hide_trivial_tau`` only affects visualization: the underlying CPST JSON
    and text outputs still contain the silent leaves. ``compact`` suppresses
    support overlays and is intended as a core/paper-facing visualization.
    """

    support_variants = frozenset(activity_supports.keys()) if activity_supports else frozenset()
    cdfg_variants = frozenset(cdfg.variants) if cdfg is not None else frozenset()
    # Use the CDFG variant universe when available. This keeps configured
    # single-variant views visually comparable with the full model family.
    all_variants = frozenset(sorted(cdfg_variants or tree.variants or _collect_tree_variants(tree) or support_variants))
    palette = _variant_palette(all_variants)

    lines = [
        "digraph ProcessTree {",
        '  graph [rankdir=TB, bgcolor="white", splines=true, nodesep=0.35, ranksep=0.82];',
        '  node [fontname="Helvetica"];',
        '  edge [fontname="Helvetica", color="#555555", arrowsize=0.8, penwidth=1.4];',
        '  labelloc="t";',
        f'  label="{_dot_escape(title)}";',
    ]

    counter = itertools.count()
    show_support_overlays = show_arc_evidence and not compact

    def visit(node):
        idx = next(counter)

        if node.op == "act":
            label = node.label or ""
        elif node.op == "tau":
            label = "τ"
        else:
            label = OPERATOR_SYMBOLS.get(node.op, str(node.op))

        fill, border = _activation_colors(node.variants, all_variants, palette)
        attrs = _pt_node_shape_and_style(node, label, fill, border)
        lines.append(f"  n{idx} [{attrs}];")

        for child_index, child in _children_for_dot(
            node,
            hide_trivial_tau=hide_trivial_tau,
        ):
            child_idx = visit(child)
            edge_color = border if node.variants != child.variants else "#555555"

            arc_label = ""
            if show_support_overlays:
                arc_label = _arc_evidence_label(
                    parent=node,
                    child_index=child_index,
                    child=child,
                    all_variants=all_variants,
                    activity_supports=activity_supports,
                    cdfg=cdfg,
                    tiny_support_threshold=tiny_support_threshold,
                )

            if arc_label:
                lines.append(
                    f'  n{idx} -> n{child_idx} '
                    f'[color="{edge_color}", fontcolor="{edge_color}", '
                    f'label="{_dot_escape(arc_label)}", fontsize=9];'
                )
            else:
                lines.append(f'  n{idx} -> n{child_idx} [color="{edge_color}"];')

        return idx

    visit(tree)

    support_note = (
        "compact view: arc support labels are suppressed"
        if compact
        else "arc labels show μ supp only for single-activity subtrees"
    )
    tau_note = (
        "trivial τ leaves are hidden unless needed to avoid unary operator nodes"
        if hide_trivial_tau
        else "trivial τ leaves are shown in this full CPST view"
    )

    lines.extend(
        _legend_lines(
            all_variants,
            palette,
            "shared/all variants",
            note=(
                "CPST node/edge color = structural availability\n"
                "gray = shared/all variants; colored = variant-specific\n"
                f"{support_note}\n"
                "small non-zero support values are shown as <0.01; exact zeros as 0\n"
                "shared subtrees show all variants; variant-specific subtrees show active variants only\n"
                f"{tau_note}\n"
                "relation-level dominance is shown in the CDFG outputs, not in CPST labels"
            ),
        )
    )

    lines.append("}")
    return "\n".join(lines)



def _children_for_dot(node, *, hide_trivial_tau: bool):
    """Return children rendered in DOT without creating unary-looking operators.

    Cleaned CPST views usually hide trivial silent leaves to reduce visual
    clutter. However, hiding the only silent alternative of an operator such as
    XOR(τ, W) would make the visualization look like an invalid/uninformative
    unary operator. In that case, the silent leaf is kept in the DOT view only.
    The underlying CPST JSON/TXT representation is not changed.
    """

    indexed_children = list(enumerate(node.children))
    if not hide_trivial_tau or node.op in {"act", "tau"}:
        return indexed_children

    rendered = [
        (idx, child)
        for idx, child in indexed_children
        if not _hide_tau_child(child, hide_trivial_tau=True)
    ]
    hidden_tau = [
        (idx, child)
        for idx, child in indexed_children
        if _hide_tau_child(child, hide_trivial_tau=True)
    ]

    # Preserve only the τ leaves whose omission would make this operator appear
    # unary in the cleaned visualization. If there are already two or more
    # rendered children, τ leaves remain hidden.
    if len(rendered) == 1 and hidden_tau:
        return sorted(rendered + hidden_tau, key=lambda item: item[0])

    return rendered

def _hide_tau_child(node, *, hide_trivial_tau: bool) -> bool:
    """Return True when a child is a trivial silent leaf hidden in DOT only."""

    return bool(hide_trivial_tau and node.op == "tau" and not node.children)


def _format_support_value(value: float, *, tiny_support_threshold: float = 0.01) -> str:
    """Format support without visually misleading ``0.00`` labels."""

    try:
        value = float(value)
    except (TypeError, ValueError):
        value = 0.0

    if value == 0:
        return "0"
    if abs(value) < tiny_support_threshold:
        return f"<{tiny_support_threshold:.2f}"
    return f"{value:.2f}"


def _pt_node_shape_and_style(node, label: str, fill: str, border: str) -> str:
    """Return DOT attributes for CPST nodes with clearer process-tree shapes."""

    if node.op == "act":
        return (
            f'label="{_dot_escape(label)}", '
            'shape=box, '
            'style="filled", '
            f'fillcolor="{fill}", color="{border}", penwidth=2, '
            'width=0.85, height=0.42, margin="0.14,0.08"'
        )

    if node.op == "tau":
        return (
            f'label="{_dot_escape(label)}", '
            'shape=box, '
            'style="filled", '
            f'fillcolor="{fill}", color="{border}", penwidth=2, '
            'width=0.55, height=0.32, margin="0.10,0.05"'
        )

    return (
        f'label="{_dot_escape(label)}", '
        'shape=circle, '
        'style="filled", '
        f'fillcolor="{fill}", color="{border}", penwidth=2.4, '
        'width=0.48, height=0.48, fixedsize=true'
    )


def _arc_evidence_label(
    *,
    parent,
    child_index: int,
    child,
    all_variants,
    activity_supports,
    cdfg,
    tiny_support_threshold: float = 0.01,
) -> str:
    """Build the CPST edge evidence label for one parent -> child arc.

    Edge labels are reserved for support because CPST edges are structural
    containment edges. Relation-level dominance is intentionally not repeated in
    CPST labels.
    """

    return _arc_support_label(
        child,
        activity_supports,
        all_variants,
        tiny_support_threshold=tiny_support_threshold,
    )


def _arc_support_label(child, activity_supports, all_variants, *, tiny_support_threshold: float = 0.01) -> str:
    """Per-variant support for single-activity subtrees.

    CPST colors encode structural availability. Support labels are shown only
    when the target subtree contains exactly one visible activity. Shared gray
    subtrees report all variants; variant-specific subtrees report only the
    variants for which that subtree is active.
    """

    if not activity_supports:
        return ""

    leaves = _visible_activity_leaves(child)
    unique_leaves = sorted(set(leaves))
    if len(unique_leaves) != 1:
        return ""

    active_variants = getattr(child, "variants", None)
    if active_variants:
        label_variants = [variant for variant in sorted(all_variants) if variant in active_variants]
    else:
        label_variants = sorted(all_variants)

    activity = unique_leaves[0]
    parts = []
    for variant in label_variants:
        variant_supports = activity_supports.get(variant, {})
        support = variant_supports.get(activity, 0.0)
        parts.append(
            f"{variant}: μ supp = "
            f"{_format_support_value(support, tiny_support_threshold=tiny_support_threshold)}"
        )

    return "\n".join(parts)

def _visible_activity_leaves(tree) -> list[str]:
    leaves = []
    for node in tree.walk():
        if node.op == "act" and node.label:
            leaves.append(node.label)
    return leaves


def _collect_tree_variants(tree):
    names = set()
    for node in tree.walk():
        if node.variants is not None:
            names.update(node.variants)
    return frozenset(names)


def _variant_palette(variants):
    return {
        variant: (
            FILL_COLORS[i % len(FILL_COLORS)],
            BORDER_COLORS[i % len(BORDER_COLORS)],
        )
        for i, variant in enumerate(sorted(variants))
    }


def _activation_colors(variants, all_variants, palette):
    if variants is None:
        return "#FFFFFF", "#999999"

    variants = frozenset(variants)

    if len(all_variants) > 1 and variants == all_variants:
        return "#E8E8E8", "#555555"

    if len(variants) == 1:
        variant = next(iter(variants))
        return palette.get(variant, ("#FFFFFF", "#333333"))

    if len(variants) > 1:
        return "#E6D9FF", "#7048A8"

    return "#FFFFFF", "#999999"


def _legend_lines(variants, palette, shared_label, note: str | None = None):
    lines = [
        "  subgraph cluster_legend {",
        '    label="Legend";',
        "    fontsize=10;",
        '    style="rounded,dashed";',
    ]

    if note:
        lines.append(
            f'    legend_note [label="{_dot_escape(note)}", shape=note, '
            'fontname="Helvetica", fontsize=10];'
        )

    if len(variants) > 1:
        lines.append(
            f'    legend_shared [label="{_dot_escape(shared_label)}", shape=box, '
            'style="filled,rounded", fillcolor="#E8E8E8", '
            'color="#555555", penwidth=2];'
        )

    for variant in sorted(variants):
        fill, border = palette[variant]
        lines.append(
            f'    {_dot_id("legend_" + variant)} '
            f'[label="{_dot_escape(variant)}", shape=box, '
            f'style="filled,rounded", fillcolor="{fill}", '
            f'color="{border}", penwidth=2];'
        )

    lines.append("  }")
    return lines


def _dot_id(value):
    safe = "".join(ch if ch.isalnum() or ch == "_" else "_" for ch in str(value))
    if not safe or safe[0].isdigit():
        safe = "n_" + safe
    return safe


def _dot_escape(value):
    return str(value).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
