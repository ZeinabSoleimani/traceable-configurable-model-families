from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field
import csv
from pathlib import Path
from typing import Any, Mapping, Sequence

from .data import Trace, VariantLog
from .stats import ProportionTest, benjamini_hochberg, two_proportion_z_test

SOURCE = "▶"
SINK = "■"
Relation = tuple[str, str]


@dataclass(frozen=True)
class RelationEvidence:
    relation: Relation
    counts: Mapping[str, int]
    outgoing_counts: Mapping[str, int]
    supports: Mapping[str, float]
    availability: frozenset[str]
    dominance: frozenset[str] | str
    tests: tuple[ProportionTest, ...] = ()

    @property
    def is_balanced(self) -> bool:
        return self.dominance == "balanced"

    @property
    def is_variant_only(self) -> bool:
        return isinstance(self.dominance, frozenset) and len(self.availability) == 1

    def annotation_label(self) -> str:
        if self.dominance == "balanced":
            return "balanced"
        values = sorted(self.dominance)
        suffix = "only" if set(values) == set(self.availability) and len(values) == 1 else "dominant"
        return "/".join(values) + f"-{suffix}"


@dataclass(frozen=True)
class CDFG:
    activities: frozenset[str]
    relations: frozenset[Relation]
    variants: tuple[str, ...]
    evidence: Mapping[Relation, RelationEvidence]
    node_availability: Mapping[str, frozenset[str]] = field(default_factory=dict)
    method_parameters: Mapping[str, Any] = field(default_factory=dict)

    def relation(self, a: str, b: str) -> RelationEvidence | None:
        return self.evidence.get((a, b))

    def variant_view_relations(self, variant: str) -> frozenset[Relation]:
        return frozenset(edge for edge, ev in self.evidence.items() if variant in ev.availability)

    def differential_relations(self) -> frozenset[Relation]:
        diff: set[Relation] = set()
        all_variants = set(self.variants)
        for edge, ev in self.evidence.items():
            if set(ev.availability) != all_variants:
                diff.add(edge)
            elif ev.dominance != "balanced":
                diff.add(edge)
        return frozenset(diff)

    def to_rows(self) -> list[dict[str, object]]:
        rows: list[dict[str, object]] = []
        for edge in sorted(self.evidence):
            ev = self.evidence[edge]
            row: dict[str, object] = {
                "source": edge[0],
                "target": edge[1],
                "availability": ";".join(sorted(ev.availability)),
                "annotation": ev.annotation_label(),
            }
            for variant in self.variants:
                row[f"count_{variant}"] = ev.counts.get(variant, 0)
                row[f"outgoing_{variant}"] = ev.outgoing_counts.get(variant, 0)
                row[f"support_{variant}"] = round(ev.supports.get(variant, 0.0), 8)
            rows.append(row)
        return rows

    def to_csv(self, path: str | Path) -> None:
        rows = self.to_rows()
        if not rows:
            return
        with Path(path).open("w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)

    def to_dot(
        self,
        *,
        colored: bool = True,
        show_supports: bool = False,
        min_support: float = 0.0,
        min_support_delta: float = 0.0,
        min_support_by_variant: Mapping[str, float] | None = None,
        dominance_only: bool = False,
        keep_lifecycle_edges: bool = True,
        title: str = "Configurable Directly-Follows Graph (CDFG)",
        view_note: str | None = None,
        show_no_filter_note: bool = False,
        tiny_support_threshold: float = 0.01,
    ) -> str:
        """Return a colored Graphviz DOT representation of the CDFG.

        The synthetic lifecycle nodes are shown explicitly as:
        - SOURCE (▶): synthetic start
        - SINK (■): synthetic end

        The DOT identifiers are Unicode-safe, so ▶ and ■ do not collapse
        into the same Graphviz node id.
        """

        variants = tuple(self.variants)
        all_variants = frozenset(variants)
        palette = _variant_color_map(variants)

        lines = [
            "digraph CDFG {",
            '  graph [rankdir=LR, bgcolor="white", splines=true, nodesep=0.60, ranksep=1.35, newrank=true, dpi=300, outputorder=edgesfirst];',
            '  node [shape=box, style="filled,rounded", fontname="Helvetica", fontsize=11];',
            '  edge [fontname="Helvetica", fontsize=10, arrowsize=0.55, penwidth=1.0];',
            '  labelloc="t";',
            f'  label="{_dot_escape(title)}";',
        ]

        nodes = sorted(self.node_availability.keys() or self.activities)

        for node in nodes:
            availability = self.node_availability.get(node, frozenset())

            if colored:
                fill, border = _availability_colors(availability, all_variants, palette)
            else:
                fill, border = "white", "black"

            if node == SOURCE:
                node_label = "▶"
                shape = "circle"
                width = "0.42"
                height = "0.42"
                margin = "0.02"
            elif node == SINK:
                node_label = "■"
                shape = "doublecircle"
                width = "0.42"
                height = "0.42"
                margin = "0.02"
            else:
                node_label = node
                if availability:
                    node_label += "\n[" + ", ".join(sorted(availability)) + "]"
                shape = "box"
                width = "0"
                height = "0"
                margin = "0.06,0.04"

            lines.append(
                f'  {_dot_id(node)} '
                f'[label="{_dot_escape(node_label)}", shape={shape}, '
                f'fillcolor="{fill}", color="{border}", penwidth=2, '
                f'width={width}, height={height}, margin="{margin}"];'
            )

        # Keep lifecycle nodes at the outer ranks without forcing all activity
        # nodes into one vertical column.
        if SOURCE in nodes:
            lines.append(f"  {{ rank=source; {_dot_id(SOURCE)}; }}")
        if SINK in nodes:
            lines.append(f"  {{ rank=sink; {_dot_id(SINK)}; }}")

        for edge in sorted(self.evidence):
            ev = self.evidence[edge]
            is_lifecycle_edge = edge[0] == SOURCE or edge[1] == SINK
            support_values = [ev.supports.get(v, 0.0) for v in variants]
            max_support = max(support_values)
            support_delta = max(support_values) - min(support_values)

            is_dominant = ev.dominance != "balanced"

            if min_support_by_variant:
                support_pass = any(
                    ev.supports.get(v, 0.0) >= min_support_by_variant.get(v, min_support)
                    for v in variants
                )
            else:
                support_pass = max_support >= min_support

            delta_pass = support_delta >= min_support_delta

            if keep_lifecycle_edges and is_lifecycle_edge:
                pass
            else:
                if dominance_only and not is_dominant:
                    continue
                if not support_pass and not delta_pass:
                    continue
            color = _edge_color(ev, all_variants, palette) if colored else "black"
            label_color = _edge_label_color(ev, palette) if colored else "black"
            penwidth = _edge_penwidth(ev, is_lifecycle_edge=is_lifecycle_edge)

            label = ev.annotation_label()
            if show_supports:
                support_text = ", ".join(
                    f"{v}:{_format_support_value(ev.supports.get(v, 0.0), tiny_support_threshold=tiny_support_threshold)}"
                    for v in variants
                )
                label += "\n" + support_text

            tooltip = "; ".join(
                f"{v}: count={ev.counts.get(v, 0)}, "
                f"support={_format_support_value(ev.supports.get(v, 0.0), tiny_support_threshold=tiny_support_threshold)}"
                for v in variants
            )

            # Lifecycle edges should strongly express start/end.
            # Other edges may still influence layout, otherwise all activities
            # collapse into one middle rank for dense cyclic graphs.
            if edge[0] == SOURCE or edge[1] == SINK:
                constraint = "true"
                weight = "20"
                minlen = "2"
            elif edge[0] == edge[1]:
                constraint = "false"
                weight = "1"
                minlen = "1"
            else:
                constraint = "true"
                weight = "1"
                minlen = "1"

            lines.append(
                f'  {_dot_id(edge[0])} -> {_dot_id(edge[1])} '
                f'[label="{_dot_escape(label)}", color="{color}", fontcolor="{label_color}", '
                f'penwidth={penwidth}, tooltip="{_dot_escape(tooltip)}", '
                f'constraint={constraint}, weight={weight}, minlen={minlen}];'
            )

        if colored:
            filter_note = _cdfg_filter_note(
                min_support=min_support,
                min_support_delta=min_support_delta,
                min_support_by_variant=min_support_by_variant,
                dominance_only=dominance_only,
                keep_lifecycle_edges=keep_lifecycle_edges,
                view_note=view_note,
                show_no_filter_note=show_no_filter_note,
            )
            lines.extend(
                _cdfg_legend_lines(
                    variants,
                    palette,
                    filter_note=filter_note,
                    method_parameters=self.method_parameters,
                )
            )

        lines.append("}")
        return "\n".join(lines)


def construct_cdfg(
    log: VariantLog,
    *,
    theta: float = 0.0,
    alpha: float = 0.05,
    n_min: int = 5,
    include_lifecycle_edges: bool = True,
    prune_disconnected: bool = True,
) -> CDFG:
    """Construct a Configurable Directly-Follows Graph.

    Parameters mirror the paper: ``theta`` controls relation availability,
    ``alpha`` controls the pairwise dominance tests, and ``n_min`` suppresses
    dominance claims for low-evidence relations.

    Pairwise dominance tests are collected for all eligible retained relations
    first and the Benjamini-Hochberg correction is then applied globally across
    that complete family of tests, as described in Algorithm 1 of the paper.
    The low-evidence guard uses retained relation counts, not the outgoing
    denominator of the source activity.
    """

    variants = log.variants
    counts_by_variant: dict[str, Counter[Relation]] = {}
    outgoing_by_variant: dict[str, Counter[str]] = {}

    for variant in variants:
        rel_counts, outgoing = directly_follows_counts(
            log.sublog(variant), include_lifecycle_edges=include_lifecycle_edges
        )
        counts_by_variant[variant] = rel_counts
        outgoing_by_variant[variant] = outgoing

    all_relations = frozenset(
        relation for counter in counts_by_variant.values() for relation in counter.keys()
    )

    # First pass: compute availability and collect all eligible pairwise tests.
    relation_data: dict[
        Relation,
        tuple[dict[str, int], dict[str, int], dict[str, float], frozenset[str]],
    ] = {}
    tests_by_relation: dict[Relation, list[ProportionTest]] = defaultdict(list)
    global_raw_tests: list[tuple[Relation, ProportionTest]] = []

    for relation in sorted(all_relations):
        a, _ = relation
        counts = {v: counts_by_variant[v].get(relation, 0) for v in variants}
        outgoing = {v: outgoing_by_variant[v].get(a, 0) for v in variants}
        supports = {
            v: counts[v] / outgoing[v] if outgoing[v] > 0 else 0.0
            for v in variants
        }
        availability = frozenset(
            v for v in variants if counts[v] > 0 and supports[v] >= theta
        )
        if not availability:
            continue

        relation_data[relation] = (counts, outgoing, supports, availability)

        if len(availability) == 1:
            continue
        if any(counts[v] < n_min for v in availability):
            continue

        for i, first in enumerate(variants):
            if first not in availability:
                continue
            for second in variants[i + 1 :]:
                if second not in availability:
                    continue
                z, p_value = two_proportion_z_test(
                    counts[first], outgoing[first], counts[second], outgoing[second]
                )
                test = ProportionTest(
                    first=first,
                    second=second,
                    support_first=supports[first],
                    support_second=supports[second],
                    z=z,
                    p_value=p_value,
                )
                global_raw_tests.append((relation, test))

    significant, adjusted = benjamini_hochberg(
        (test.p_value for _, test in global_raw_tests), alpha
    )
    for index, (relation, test) in enumerate(global_raw_tests):
        tests_by_relation[relation].append(
            ProportionTest(
                first=test.first,
                second=test.second,
                support_first=test.support_first,
                support_second=test.support_second,
                z=test.z,
                p_value=test.p_value,
                adjusted_p_value=adjusted[index],
                significant=significant[index],
            )
        )

    # Second pass: assign dominance labels using globally adjusted tests.
    evidence: dict[Relation, RelationEvidence] = {}
    for relation in sorted(relation_data):
        counts, outgoing, supports, availability = relation_data[relation]
        tests = tuple(tests_by_relation.get(relation, ()))
        if len(availability) == 1:
            dominance: frozenset[str] | str = availability
        elif not tests:
            dominance = "balanced"
        else:
            dominance = _dominance_from_corrected_tests(
                variants=variants,
                availability=availability,
                supports=supports,
                tests=tests,
            )
        evidence[relation] = RelationEvidence(
            relation=relation,
            counts=counts,
            outgoing_counts=outgoing,
            supports=supports,
            availability=availability,
            dominance=dominance,
            tests=tests,
        )

    if prune_disconnected:
        evidence = _prune_disconnected_views(evidence, variants)

    node_availability = _node_availability(evidence, variants)
    return CDFG(
        activities=log.activities,
        relations=frozenset(evidence.keys()),
        variants=variants,
        evidence=evidence,
        node_availability=node_availability,
        method_parameters={
            "theta": theta,
            "alpha": alpha,
            "n_min": n_min,
            "include_lifecycle_edges": include_lifecycle_edges,
            "dominance_correction": "global_benjamini_hochberg",
            "n_min_basis": "relation_count",
            "pruning": "directed_source_sink_reachability",
        },
    )


def _dominance_from_corrected_tests(
    *,
    variants: tuple[str, ...],
    availability: frozenset[str],
    supports: Mapping[str, float],
    tests: tuple[ProportionTest, ...],
) -> frozenset[str] | str:
    """Assign a dominance annotation from globally corrected tests."""

    if not any(test.significant for test in tests):
        return "balanced"

    max_support = max(supports[v] for v in availability)
    top_variants = {v for v in availability if supports[v] == max_support}
    dominant: set[str] = set(top_variants)

    def is_significantly_lower_than_any_top(variant: str) -> bool:
        for top in top_variants:
            if top == variant:
                continue
            for test in tests:
                if {test.first, test.second} != {top, variant} or not test.significant:
                    continue
                if supports[top] > supports[variant]:
                    return True
        return False

    for variant in variants:
        if variant in availability and not is_significantly_lower_than_any_top(variant):
            dominant.add(variant)

    if dominant == set(availability):
        return "balanced"
    return frozenset(dominant)


def directly_follows_counts(
    traces: list[Trace],
    *,
    include_lifecycle_edges: bool = True,
) -> tuple[Counter[Relation], Counter[str]]:
    counts: Counter[Relation] = Counter()
    outgoing: Counter[str] = Counter()
    for trace in traces:
        if include_lifecycle_edges:
            padded = (SOURCE, *trace, SINK)
        else:
            padded = trace
        for a, b in zip(padded, padded[1:]):
            counts[(a, b)] += 1
            outgoing[a] += 1
    return counts, outgoing


def _node_availability(
    evidence: Mapping[Relation, RelationEvidence], variants: tuple[str, ...]
) -> dict[str, frozenset[str]]:
    node_to_variants: dict[str, set[str]] = defaultdict(set)
    for (a, b), ev in evidence.items():
        node_to_variants[a].update(ev.availability)
        node_to_variants[b].update(ev.availability)
    for special in (SOURCE, SINK):
        if special in node_to_variants:
            node_to_variants[special].update(variants)
    return {node: frozenset(values) for node, values in node_to_variants.items()}


def _prune_disconnected_views(
    evidence: Mapping[Relation, RelationEvidence], variants: tuple[str, ...]
) -> dict[Relation, RelationEvidence]:
    """Prune retained evidence views to satisfy directed source/sink reachability.

    When lifecycle edges are available, this enforces the C-DFG well-formedness
    condition that every retained node in each variant view is reachable from
    ``SOURCE`` and can reach ``SINK``. If lifecycle nodes are not present, the
    function falls back to the largest weakly connected component.
    """

    keep_by_edge: dict[Relation, set[str]] = {
        edge: set(ev.availability) for edge, ev in evidence.items()
    }
    for variant in variants:
        edges = [edge for edge, ev in evidence.items() if variant in ev.availability]
        if not edges:
            continue
        nodes = {node for edge in edges for node in edge}

        if SOURCE in nodes and SINK in nodes:
            forward: dict[str, set[str]] = {node: set() for node in nodes}
            reverse: dict[str, set[str]] = {node: set() for node in nodes}
            for a, b in edges:
                forward[a].add(b)
                reverse[b].add(a)

            reachable_from_source = _directed_reachable(forward, SOURCE)
            can_reach_sink = _directed_reachable(reverse, SINK)
            retained_nodes = reachable_from_source & can_reach_sink
        else:
            retained_nodes = _largest_weak_component(nodes, edges)

        for edge in edges:
            if edge[0] not in retained_nodes or edge[1] not in retained_nodes:
                keep_by_edge[edge].discard(variant)

    pruned: dict[Relation, RelationEvidence] = {}
    for edge, ev in evidence.items():
        availability = frozenset(keep_by_edge[edge])
        if not availability:
            continue
        dominance = ev.dominance
        if isinstance(dominance, frozenset):
            dominance = frozenset(v for v in dominance if v in availability)
            if not dominance or dominance == availability and len(availability) > 1:
                dominance = "balanced"
        pruned[edge] = RelationEvidence(
            relation=edge,
            counts=ev.counts,
            outgoing_counts=ev.outgoing_counts,
            supports=ev.supports,
            availability=availability,
            dominance=dominance,
            tests=ev.tests,
        )
    return pruned


def _directed_reachable(graph: Mapping[str, set[str]], start: str) -> set[str]:
    reachable: set[str] = set()
    queue: deque[str] = deque([start])
    reachable.add(start)
    while queue:
        node = queue.popleft()
        for nxt in graph.get(node, set()):
            if nxt not in reachable:
                reachable.add(nxt)
                queue.append(nxt)
    return reachable


def _largest_weak_component(nodes: set[str], edges: Sequence[Relation]) -> set[str]:
    graph: dict[str, set[str]] = {node: set() for node in nodes}
    for a, b in edges:
        graph[a].add(b)
        graph[b].add(a)

    components: list[set[str]] = []
    seen: set[str] = set()
    for node in nodes:
        if node in seen:
            continue
        comp: set[str] = set()
        queue: deque[str] = deque([node])
        seen.add(node)
        while queue:
            cur = queue.popleft()
            comp.add(cur)
            for nxt in graph[cur]:
                if nxt not in seen:
                    seen.add(nxt)
                    queue.append(nxt)
        components.append(comp)
    return max(components, key=len) if components else set()


# ---------------------------------------------------------------------------
# DOT/color helpers
# ---------------------------------------------------------------------------

_DOT_FILL_COLORS = [
    "#D9E8FF",  # blue
    "#FFE2C2",  # orange
    "#D8F3DC",  # green
    "#FADADD",  # red/pink
    "#E6D9FF",  # purple
    "#FFF2B2",  # yellow
    "#E6CCB2",  # brown
    "#D9F0F2",  # cyan
]

_DOT_EDGE_COLORS = [
    "#2F6BBA",
    "#C96A00",
    "#2B8A3E",
    "#C92A2A",
    "#7048A8",
    "#A88700",
    "#8B5E34",
    "#0B7285",
]


def _variant_color_map(variants: tuple[str, ...]) -> dict[str, tuple[str, str]]:
    return {
        variant: (
            _DOT_FILL_COLORS[i % len(_DOT_FILL_COLORS)],
            _DOT_EDGE_COLORS[i % len(_DOT_EDGE_COLORS)],
        )
        for i, variant in enumerate(sorted(variants))
    }


def _availability_colors(
    availability: frozenset[str],
    all_variants: frozenset[str],
    palette: dict[str, tuple[str, str]],
) -> tuple[str, str]:
    if not availability:
        return "#FFFFFF", "#999999"
    if availability == all_variants and len(all_variants) > 1:
        return "#E8E8E8", "#555555"
    if len(availability) == 1:
        variant = next(iter(availability))
        return palette.get(variant, ("#FFFFFF", "#333333"))
    return "#E6D9FF", "#7048A8"


def _edge_color(
    ev: RelationEvidence,
    all_variants: frozenset[str],
    palette: dict[str, tuple[str, str]],
) -> str:
    """Return the visual edge color from relation availability only.

    Dominance must not color the edge: a relation observed in multiple variants
    is a shared relation and is drawn gray/black even when its label says that
    one variant is statistically dominant. Variant colors are used only when the
    relation is available in exactly one variant.
    """

    if len(ev.availability) == 1:
        variant = next(iter(ev.availability))
        return palette.get(variant, ("#FFFFFF", "#333333"))[1]

    if len(ev.availability) > 1:
        return "#555555" if ev.availability == all_variants else "#777777"

    return "#555555"


def _edge_label_color(
    ev: RelationEvidence,
    palette: dict[str, tuple[str, str]],
) -> str:
    """Return the edge-label color from dominance/annotation semantics.

    The label may use a variant color to highlight ``<variant>-dominant`` or
    ``<variant>-only`` annotations. Balanced shared labels remain black.
    """

    if ev.dominance == "balanced":
        return "#111111"

    if isinstance(ev.dominance, frozenset) and len(ev.dominance) == 1:
        variant = next(iter(ev.dominance))
        return palette.get(variant, ("#FFFFFF", "#333333"))[1]

    if isinstance(ev.dominance, frozenset) and len(ev.dominance) > 1:
        return "#7048A8"

    return "#111111"


def _edge_penwidth(ev: RelationEvidence, *, is_lifecycle_edge: bool = False) -> str:
    """Use compact edge widths independent of dominance.

    Dominance is encoded in the annotation text/color, not in the edge stroke.
    Lifecycle edges are kept only slightly stronger to preserve start/end flow.
    """

    if is_lifecycle_edge:
        return "1.25"
    if len(ev.availability) == 1:
        return "1.15"
    return "1.00"


def _cdfg_legend_lines(
    variants: tuple[str, ...],
    palette: dict[str, tuple[str, str]],
    filter_note: str | None = None,
    method_parameters: Mapping[str, Any] | None = None,
) -> list[str]:
    note_lines = [
        "CDFG node color = activity availability",
        "CDFG edge color = relation availability only",
        "edge-label color/text = dominance annotation",
        "full CDFG = all retained relations after method parameters",
        "core CDFG = same evidence plus visualization filter for readability",
        "gray/black edge = relation shared by multiple variants",
        "colored edge = relation observed only for that variant",
        "<variant>-dominant label = shared relation statistically dominant for that variant",
        "dominance uses pairwise z-tests with Benjamini-Hochberg FDR correction",
        "edge labels show per-variant relation support",
        "small non-zero support values are shown as <0.01; exact zeros as 0",
    ]
    note = "\n".join(note_lines)

    lines = [
        "  subgraph cluster_legend {",
        "    label=\"Legend\";",
        "    fontsize=10;",
        "    style=\"rounded,dashed\";",
        f"    legend_note [label=\"{_dot_escape(note)}\", shape=note, fontsize=10];",
    ]

    method_note = _cdfg_method_note(method_parameters)
    if method_note:
        lines.append(
            f"    legend_method [label=\"{_dot_escape(method_note)}\", "
            "shape=note, fontsize=10];"
        )

    if filter_note:
        lines.append(
            f"    legend_filter [label=\"{_dot_escape(filter_note)}\", "
            "shape=note, fontsize=10];"
        )

    lines.append(
        "    legend_shared [label=\"shared + balanced\", shape=box, "
        "style=\"filled,rounded\", fillcolor=\"#E8E8E8\", color=\"#555555\", penwidth=2];"
    )

    for variant in sorted(variants):
        fill, edge = palette[variant]
        safe = _dot_id("legend_" + variant)
        lines.append(
            f"    {safe} [label=\"{_dot_escape(variant)}\", shape=box, "
            f"style=\"filled,rounded\", fillcolor=\"{fill}\", "
            f"color=\"{edge}\", penwidth=2];"
        )

    if len(variants) > 2:
        lines.append(
            "    legend_partial [label=\"partial/multi-variant\", shape=box, "
            "style=\"filled,rounded\", fillcolor=\"#E6D9FF\", color=\"#7048A8\", penwidth=2];"
        )

    lines.append("  }")
    return lines


def _cdfg_method_note(method_parameters: Mapping[str, Any] | None) -> str | None:
    if not method_parameters:
        return None

    theta = method_parameters.get("theta")
    alpha = method_parameters.get("alpha")
    n_min = method_parameters.get("n_min")
    lifecycle = method_parameters.get("include_lifecycle_edges")

    parts = ["Method parameters applied to all CDFG views"]

    if theta is not None:
        parts.append(f"theta availability threshold = {theta:g}")
    if alpha is not None:
        parts.append(f"alpha for dominance tests = {alpha:g}")
    if n_min is not None:
        parts.append(f"n_min for dominance tests = {n_min}")
    if lifecycle is not None:
        parts.append(f"lifecycle edges included = {bool(lifecycle)}")

    return "\n".join(parts)


def _cdfg_filter_note(
    *,
    min_support: float,
    min_support_delta: float,
    min_support_by_variant,
    dominance_only: bool,
    keep_lifecycle_edges: bool,
    view_note: str | None = None,
    show_no_filter_note: bool = False,
) -> str | None:
    """Legend text for additional visualization filters.

    Method parameters such as theta, alpha, n_min, and BH-FDR are applied during
    CDFG construction and therefore affect all CDFG views. The filters reported
    here are extra display filters used only for core CDFG visualizations.
    """

    has_global_filter = min_support > 0 or min_support_delta > 0
    has_variant_filter = bool(min_support_by_variant)
    has_dominance_filter = dominance_only

    parts: list[str] = []

    if view_note:
        parts.extend(view_note.splitlines())

    if not (has_global_filter or has_variant_filter or has_dominance_filter):
        if show_no_filter_note:
            parts.append("Additional visualization filter: none")
            parts.append("all method-retained CDFG relations are shown")
        return "\n".join(parts) if parts else None

    parts.append("Additional visualization filter for core CDFG")

    if has_variant_filter:
        variant_text = ", ".join(
            f"{variant}>={threshold:g}"
            for variant, threshold in sorted(min_support_by_variant.items())
        )
        parts.append(f"variant support: {variant_text}")
    elif min_support > 0:
        parts.append(f"max support >= {min_support:g}")

    if min_support_delta > 0:
        parts.append(f"support delta >= {min_support_delta:g}")

    if dominance_only:
        parts.append("dominant edges only")

    if keep_lifecycle_edges:
        parts.append("lifecycle edges always kept")

    return "\n".join(parts)



def _format_support_value(value: float, *, tiny_support_threshold: float = 0.01) -> str:
    """Format support without visually misleading ``0.00`` labels."""

    try:
        value = float(value)
    except (TypeError, ValueError):
        value = 0.0

    if value == 0:
        return "0"
    if abs(value) < tiny_support_threshold:
        return f"<{tiny_support_threshold:.2f}"
    return f"{value:.2f}"

def _dot_id(value: str) -> str:
    """
    Create a stable Graphviz-safe node id.

    Unicode lifecycle nodes such as ▶ and ■ must not collapse
    to the same identifier.
    """
    value = str(value)

    safe_parts = []
    for ch in value:
        if ch.isalnum() or ch == "_":
            safe_parts.append(ch)
        else:
            safe_parts.append(f"_u{ord(ch):x}_")

    safe = "".join(safe_parts)

    if not safe or safe[0].isdigit():
        safe = "n_" + safe

    return safe


def _dot_escape(value: str) -> str:
    return str(value).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
