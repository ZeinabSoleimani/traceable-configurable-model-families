from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Iterable, Sequence

from .data import Trace, collapse_consecutive_duplicates
from .ptree import PAR, SEQ, XOR, ProcessTree, sequence_or_single, xor_or_single


@dataclass(frozen=True)
class DiscoveryConfig:
    """Configuration for the built-in Inductive-style process-tree miner.

    This miner is intentionally dependency-free. It implements exact base cases,
    optional behavior, sequence cuts, simple XOR cuts, simple parallel cuts, and
    a bounded exact-log fallback. When a log is too heterogeneous for a compact
    structural cut, the fallback switches to a compact flower model instead of
    enumerating a very large exact tree. This keeps the model sound and readable
    for previously unseen logs without relying on dataset-specific labels.
    """

    max_depth: int = 100
    collapse_consecutive_repetitions: bool = False
    max_exact_log_traces: int = 100
    max_exact_log_leaves: int = 500
    use_flower_fallback: bool = True


def mine_process_tree(
    traces: Iterable[Sequence[str]],
    *,
    config: DiscoveryConfig | None = None,
) -> ProcessTree:
    cfg = config or DiscoveryConfig()
    normalized = [tuple(str(a) for a in trace) for trace in traces]
    if cfg.collapse_consecutive_repetitions:
        normalized = [collapse_consecutive_duplicates(trace) for trace in normalized]
    return _mine(tuple(normalized), cfg=cfg, depth=0, seen=frozenset())


def exact_log_tree(traces: Iterable[Sequence[str]]) -> ProcessTree:
    """Return an exact XOR-over-traces tree covering exactly the given traces."""

    counts = Counter(tuple(trace) for trace in traces)
    branches: list[ProcessTree] = []
    for trace in sorted(counts):
        if not trace:
            branches.append(ProcessTree.tau())
        else:
            branches.append(sequence_or_single([ProcessTree.activity(a) for a in trace]))
    return xor_or_single(branches)


def flower_tree(traces: Iterable[Sequence[str]]) -> ProcessTree:
    """Return a compact sound fallback over the activities observed in traces.

    The model is intentionally permissive: it accepts any non-empty sequence over
    the observed activities, and it includes an optional tau branch when empty
    traces were observed. It is used only when exact enumeration would create an
    unreadably large fallback tree.
    """

    traces = [tuple(trace) for trace in traces]
    activities = sorted({activity for trace in traces for activity in trace})
    if not activities:
        return ProcessTree.tau()

    body = xor_or_single([ProcessTree.activity(activity) for activity in activities])
    redo = xor_or_single([ProcessTree.tau(), *[ProcessTree.activity(activity) for activity in activities]])
    loop = ProcessTree.operator("loop", [body, redo]).simplified()

    if any(len(trace) == 0 for trace in traces):
        return xor_or_single([ProcessTree.tau(), loop]).simplified()
    return loop


def _mine(
    traces: tuple[Trace, ...],
    *,
    cfg: DiscoveryConfig,
    depth: int,
    seen: frozenset[tuple[Trace, ...]],
) -> ProcessTree:
    traces = tuple(trace for trace in traces)
    if depth > cfg.max_depth:
        return _fallback_model(traces, cfg)
    signature = tuple(sorted(traces))
    if signature in seen:
        return _fallback_model(traces, cfg)
    seen = seen | {signature}

    if not traces or all(len(trace) == 0 for trace in traces):
        return ProcessTree.tau()

    empty_count = sum(1 for trace in traces if not trace)
    non_empty = tuple(trace for trace in traces if trace)
    if empty_count and non_empty:
        return xor_or_single([ProcessTree.tau(), _mine(non_empty, cfg=cfg, depth=depth + 1, seen=seen)])

    unique_traces = set(non_empty)
    if len(unique_traces) == 1:
        trace = next(iter(unique_traces))
        return sequence_or_single([ProcessTree.activity(a) for a in trace])

    activities = sorted({a for trace in non_empty for a in trace})
    if len(activities) == 1:
        # Compact A+ model. The redo branch is tau, not A, so even and odd
        # repetition counts are both represented by loop unfoldings.
        act = ProcessTree.activity(activities[0])
        return ProcessTree.operator("loop", [act, ProcessTree.tau()])

    xor_cut = _find_xor_cut(non_empty)
    if xor_cut is not None:
        branches = []
        for component in xor_cut:
            component_traces = [trace for trace in non_empty if set(trace).issubset(component)]
            if component_traces:
                branches.append(_mine(tuple(component_traces), cfg=cfg, depth=depth + 1, seen=seen))
        if len(branches) > 1:
            return ProcessTree.operator(XOR, branches)

    seq_cut = _find_sequence_cut(non_empty)
    if seq_cut is not None and len(seq_cut) > 1:
        children = []
        for block in seq_cut:
            projected = [tuple(a for a in trace if a in block) for trace in non_empty]
            children.append(_mine(tuple(projected), cfg=cfg, depth=depth + 1, seen=seen))
        return ProcessTree.operator(SEQ, children).simplified()

    parallel_cut = _find_parallel_cut(non_empty)
    if parallel_cut is not None and len(parallel_cut) > 1:
        children = []
        for block in parallel_cut:
            projected = [tuple(a for a in trace if a in block) for trace in non_empty]
            children.append(_mine(tuple(projected), cfg=cfg, depth=depth + 1, seen=seen))
        return ProcessTree.operator(PAR, children).simplified()

    return _fallback_model(non_empty, cfg)


def _fallback_model(traces: Iterable[Sequence[str]], cfg: DiscoveryConfig) -> ProcessTree:
    traces = tuple(tuple(trace) for trace in traces)
    unique = set(traces)
    exact_leaf_count = sum(max(1, len(trace)) for trace in unique)

    if (
        cfg.use_flower_fallback
        and (
            len(unique) > cfg.max_exact_log_traces
            or exact_leaf_count > cfg.max_exact_log_leaves
        )
    ):
        return flower_tree(traces)

    return exact_log_tree(traces)


def _find_xor_cut(traces: tuple[Trace, ...]) -> list[frozenset[str]] | None:
    """Detect a simple XOR cut via disconnected co-occurrence components."""

    activities = sorted({a for trace in traces for a in trace})
    if len(activities) < 2:
        return None
    graph: dict[str, set[str]] = {a: set() for a in activities}
    for trace in traces:
        present = set(trace)
        for a in present:
            graph[a].update(present - {a})
    components = _components(graph)
    if len(components) <= 1:
        return None
    if all(any(set(trace).issubset(comp) for comp in components) for trace in traces):
        return components
    return None


def _find_sequence_cut(traces: tuple[Trace, ...]) -> list[frozenset[str]] | None:
    """Detect sequence blocks using eventually-follows comparability."""

    activities = sorted({a for trace in traces for a in trace})
    if len(activities) < 2:
        return None
    ef = _eventually_follows(traces, activities)

    # Activities that appear in both orders or are incomparable must stay in the
    # same sequence block.
    merge_graph: dict[str, set[str]] = {a: set() for a in activities}
    for i, a in enumerate(activities):
        for b in activities[i + 1 :]:
            a_before_b = (a, b) in ef
            b_before_a = (b, a) in ef
            if a_before_b == b_before_a:
                merge_graph[a].add(b)
                merge_graph[b].add(a)
    blocks = _components(merge_graph)
    if len(blocks) <= 1:
        return None

    block_index = {a: idx for idx, block in enumerate(blocks) for a in block}
    before: dict[int, set[int]] = defaultdict(set)
    indegree = {idx: 0 for idx in range(len(blocks))}
    for a in activities:
        for b in activities:
            if a == b:
                continue
            ia, ib = block_index[a], block_index[b]
            if ia == ib:
                continue
            if (a, b) in ef and (b, a) not in ef and ib not in before[ia]:
                before[ia].add(ib)
                indegree[ib] += 1

    ordered_indices = _topological_order(before, indegree)
    if ordered_indices is None or len(ordered_indices) <= 1:
        return None

    # Reject cuts with no actual cross-block order evidence.
    if not any(before.values()):
        return None
    return [blocks[idx] for idx in ordered_indices]


def _find_parallel_cut(traces: tuple[Trace, ...]) -> list[frozenset[str]] | None:
    """Detect a small parallel cut when activities occur once in varying orders."""

    activities = sorted({a for trace in traces for a in trace})
    if len(activities) < 2:
        return None
    activity_set = set(activities)
    if not all(set(trace) == activity_set for trace in traces):
        return None
    if not all(len(trace) == len(set(trace)) for trace in traces):
        return None
    ef = _eventually_follows(traces, activities)
    both_order_pairs = 0
    total_pairs = 0
    for i, a in enumerate(activities):
        for b in activities[i + 1 :]:
            total_pairs += 1
            if (a, b) in ef and (b, a) in ef:
                both_order_pairs += 1
    if total_pairs and both_order_pairs == total_pairs:
        return [frozenset({a}) for a in activities]
    return None


def _eventually_follows(traces: tuple[Trace, ...], activities: Sequence[str]) -> set[tuple[str, str]]:
    ef: set[tuple[str, str]] = set()
    for trace in traces:
        for i, a in enumerate(trace):
            for b in trace[i + 1 :]:
                if a != b:
                    ef.add((a, b))
    return ef


def _components(graph: dict[str, set[str]]) -> list[frozenset[str]]:
    seen: set[str] = set()
    components: list[frozenset[str]] = []
    for node in sorted(graph):
        if node in seen:
            continue
        stack = [node]
        seen.add(node)
        comp: set[str] = set()
        while stack:
            cur = stack.pop()
            comp.add(cur)
            for nxt in graph[cur]:
                if nxt not in seen:
                    seen.add(nxt)
                    stack.append(nxt)
        components.append(frozenset(comp))
    components.sort(key=lambda c: sorted(c))
    return components


def _topological_order(before: dict[int, set[int]], indegree: dict[int, int]) -> list[int] | None:
    queue = sorted(idx for idx, value in indegree.items() if value == 0)
    order: list[int] = []
    indegree = dict(indegree)
    while queue:
        idx = queue.pop(0)
        order.append(idx)
        for nxt in sorted(before.get(idx, set())):
            indegree[nxt] -= 1
            if indegree[nxt] == 0:
                queue.append(nxt)
    if len(order) != len(indegree):
        return None
    return order
