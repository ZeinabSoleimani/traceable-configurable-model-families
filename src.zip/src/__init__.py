"""Evidence-guided configurable process tree enrichment.

The package implements the core artifacts described in the paper:

* variant-labeled event logs,
* Configurable Directly-Follows Graphs (C-DFGs),
* data-derived configurable process trees, and
* an enrichment pipeline with anchor-localization and structure-first merge
  construction paths.
"""

from .data import Case, VariantLog
from .cdfg import CDFG, RelationEvidence, construct_cdfg
from .ptree import ProcessTree
from .enrichment import (
    CONSTRUCTION_ANCHOR_LOCALIZATION,
    CONSTRUCTION_STRUCTURE_FIRST_MERGE,
    EnrichmentConfig,
    EnrichmentResult,
    enrich_process_tree,
)

__all__ = [
    "Case",
    "VariantLog",
    "CDFG",
    "RelationEvidence",
    "construct_cdfg",
    "ProcessTree",
    "CONSTRUCTION_ANCHOR_LOCALIZATION",
    "CONSTRUCTION_STRUCTURE_FIRST_MERGE",
    "EnrichmentConfig",
    "EnrichmentResult",
    "enrich_process_tree",
]
