from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Mapping, Sequence

from .cdfg import CDFG, SINK, SOURCE, construct_cdfg
from .data import Trace, VariantLog, collapse_consecutive_duplicates
from .discovery import DiscoveryConfig, exact_log_tree, mine_process_tree
from .ptree import LOOP, PAR, SEQ, TAU, XOR, ProcessTree, sequence_or_single

GapKey = tuple[int, str, str]

CONSTRUCTION_ANCHOR_LOCALIZATION = "anchor_localization"
CONSTRUCTION_STRUCTURE_FIRST_MERGE = "structure_first_merge"


@dataclass(frozen=True)
class EnrichmentConfig:
    theta: float = 0.0
    alpha: float = 0.05
    n_min: int = 5
    min_shared_activities: int = 2
    collapse_repeated_shared_activities: bool = True
    discovery: DiscoveryConfig = field(default_factory=DiscoveryConfig)
    include_lifecycle_edges: bool = True
    compact_return_cycles: bool = True


@dataclass(frozen=True)
class ResidualFragment:
    variant: str
    gap: GapKey
    log: tuple[Trace, ...]
    tree: ProcessTree


@dataclass(frozen=True)
class EnrichmentResult:
    cdfg: CDFG
    shared_activities: frozenset[str]
    shared_context: ProcessTree | None
    tree: ProcessTree
    fragments: tuple[ResidualFragment, ...]
    used_fallback: bool
    construction_mode: str = CONSTRUCTION_ANCHOR_LOCALIZATION
    construction_note: str = ""
    activity_supports: Mapping[str, Mapping[str, float]] = field(default_factory=dict)

    def configured_trees(self) -> dict[str, ProcessTree]:
        return {variant: self.tree.project(variant) for variant in self.cdfg.variants}


def enrich_process_tree(log: VariantLog, *, config: EnrichmentConfig | None = None) -> EnrichmentResult:
    cfg = config or EnrichmentConfig()
    cdfg = construct_cdfg(
        log,
        theta=cfg.theta,
        alpha=cfg.alpha,
        n_min=cfg.n_min,
        include_lifecycle_edges=cfg.include_lifecycle_edges,
    )
    variants = log.variants
    activity_supports = _activity_case_supports(log, variants)
    shared_activities = _common_activities_from_cdfg(cdfg)

    if len(shared_activities) < cfg.min_shared_activities:
        return _structure_first_result(
            log,
            variants,
            cfg.discovery,
            cdfg=cdfg,
            shared_activities=shared_activities,
            shared_context=None,
            activity_supports=activity_supports,
            note=(
                "structure-first merge used because the number of common "
                "activities is below min_shared_activities"
            ),
        )

    shared_log = _shared_context_log(
        log,
        shared_activities,
        collapse_repeated=cfg.collapse_repeated_shared_activities,
    )
    if not shared_log or all(not trace for trace in shared_log):
        return _structure_first_result(
            log,
            variants,
            cfg.discovery,
            cdfg=cdfg,
            shared_activities=shared_activities,
            shared_context=None,
            activity_supports=activity_supports,
            note="structure-first merge used because the shared-context log is empty",
        )

    shared_context = mine_process_tree(shared_log, config=cfg.discovery).simplified()
    if shared_context.visible_leaf_count() < cfg.min_shared_activities:
        return _structure_first_result(
            log,
            variants,
            cfg.discovery,
            cdfg=cdfg,
            shared_activities=shared_activities,
            shared_context=shared_context,
            activity_supports=activity_supports,
            note=(
                "structure-first merge used because the mined shared context "
                "has too few visible activities"
            ),
        )

    if not _is_pure_sequence_anchor_context(shared_context):
        return _structure_first_result(
            log,
            variants,
            cfg.discovery,
            cdfg=cdfg,
            shared_activities=shared_activities,
            shared_context=shared_context,
            activity_supports=activity_supports,
            note=(
                "structure-first merge used because the mined shared context "
                "contains non-linear process-tree structure"
            ),
        )

    anchor_sequence = _select_executable_anchor_sequence(
        log,
        shared_context=shared_context,
        shared_activities=shared_activities,
        collapse_repeated=cfg.collapse_repeated_shared_activities,
    )
    if len(anchor_sequence) < cfg.min_shared_activities:
        return _structure_first_result(
            log,
            variants,
            cfg.discovery,
            cdfg=cdfg,
            shared_activities=shared_activities,
            shared_context=shared_context,
            activity_supports=activity_supports,
            note=(
                "structure-first merge used because no reliable executable "
                "sequence anchor could be matched in every trace"
            ),
        )

    # The residual-localization step is sequence-anchor based, so the shared
    # context used for insertion must be an executable sequence, not a flattened
    # canonical order of an arbitrary XOR/parallel/exact-log tree.
    effective_shared_context = sequence_or_single(
        [ProcessTree.activity(activity) for activity in anchor_sequence]
    )
    shared_configurable = effective_shared_context.with_variants_recursive(variants)

    fragment_logs = _collect_residual_fragment_logs(log, anchor_sequence)
    fragments: list[ResidualFragment] = []
    for (variant, gap), block_log in sorted(fragment_logs.items(), key=lambda item: (item[0][0], item[0][1])):
        if all(len(block) == 0 for block in block_log):
            continue
        fragment_tree = _mine_residual_fragment_tree(
            block_log,
            gap=gap,
            discovery_cfg=cfg.discovery,
            compact_return_cycles=cfg.compact_return_cycles,
        ).simplified()
        fragment_tree.set_variants_recursive({variant})
        fragments.append(
            ResidualFragment(
                variant=variant,
                gap=gap,
                log=tuple(block_log),
                tree=fragment_tree,
            )
        )

    enriched = _insert_fragments_into_sequence_context(shared_configurable, anchor_sequence, fragments, variants)
    return EnrichmentResult(
        cdfg=cdfg,
        shared_activities=shared_activities,
        shared_context=effective_shared_context,
        tree=enriched,
        fragments=tuple(fragments),
        used_fallback=False,
        construction_mode=CONSTRUCTION_ANCHOR_LOCALIZATION,
        construction_note=(
            "anchor-localization path used with an executable shared sequence"
            + (" and compact residual return-cycle factoring" if cfg.compact_return_cycles else "")
        ),
        activity_supports=activity_supports,
    )


def _is_pure_sequence_anchor_context(tree: ProcessTree) -> bool:
    """Return whether the mined context can be used as a sequence anchor.

    Residual localization inserts fragments into gaps of a shared sequence.  If
    the mined shared context contains XOR, parallel, or loop structure, reducing
    it to a longest common sequence would lose non-linear shared behavior.  Such
    logs are handled by the structure-first merge path instead.
    """

    if tree.op in {XOR, PAR, LOOP}:
        return False
    return all(_is_pure_sequence_anchor_context(child) for child in tree.children)


def _select_executable_anchor_sequence(
    log: VariantLog,
    *,
    shared_context: ProcessTree,
    shared_activities: frozenset[str],
    collapse_repeated: bool,
) -> tuple[str, ...]:
    """Select a sequence anchor that is actually executable in the log.

    Residual insertion is based on gaps before, between, and after anchor
    activities. Therefore the anchor must be a subsequence of every trace. The
    mined context is already known to be a pure sequence context. This helper
    accepts the mined sequence only when it is supported by the data; otherwise
    it derives a conservative consensus subsequence directly from the observed
    traces. Non-linear shared contexts are not flattened here; they are handled
    by the structure-first merge path.
    """

    mined_sequence = shared_context.canonical_sequence()
    if (
        shared_context.op == SEQ
        and mined_sequence
        and _anchor_sequence_is_supported(log, mined_sequence)
    ):
        return tuple(mined_sequence)

    consensus = _consensus_common_subsequence(
        log,
        shared_activities,
        collapse_repeated=collapse_repeated,
    )
    if consensus and _anchor_sequence_is_supported(log, consensus):
        return consensus

    return tuple()


def _consensus_common_subsequence(
    log: VariantLog,
    shared_activities: frozenset[str],
    *,
    collapse_repeated: bool,
) -> tuple[str, ...]:
    """Heuristically compute a common subsequence of all projected traces.

    The procedure is deterministic and data-derived: start with the shortest
    projected trace and repeatedly reduce it by pairwise LCS against the next
    shortest projected trace. This is deliberately conservative. If the log has
    no stable shared execution spine, the returned sequence becomes empty and the
    caller can use the structure-first merge path instead of inventing structure.
    """

    projected = []
    for case in log.cases:
        trace = tuple(activity for activity in case.trace if activity in shared_activities)
        if collapse_repeated:
            trace = collapse_consecutive_duplicates(trace)
        projected.append(trace)

    if not projected or any(len(trace) == 0 for trace in projected):
        return tuple()

    projected.sort(key=lambda trace: (len(trace), trace))
    candidate = projected[0]
    for trace in projected[1:]:
        candidate = _lcs(candidate, trace)
        if not candidate:
            return tuple()
    return candidate


def _lcs(left: Sequence[str], right: Sequence[str]) -> tuple[str, ...]:
    """Return one deterministic longest common subsequence."""

    if not left or not right:
        return tuple()

    # Dynamic programming over lengths only. The candidate is usually the
    # shortest projected trace, so this stays small even for large logs.
    n, m = len(left), len(right)
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n - 1, -1, -1):
        li = left[i]
        row = dp[i]
        next_row = dp[i + 1]
        for j in range(m - 1, -1, -1):
            if li == right[j]:
                row[j] = 1 + next_row[j + 1]
            else:
                row[j] = max(next_row[j], row[j + 1])

    out: list[str] = []
    i = j = 0
    while i < n and j < m:
        if left[i] == right[j]:
            out.append(left[i])
            i += 1
            j += 1
        elif dp[i + 1][j] >= dp[i][j + 1]:
            i += 1
        else:
            j += 1
    return tuple(out)


def _mine_residual_fragment_tree(
    block_log: Sequence[Trace],
    *,
    gap: GapKey,
    discovery_cfg: DiscoveryConfig,
    compact_return_cycles: bool,
) -> ProcessTree:
    """Mine a residual fragment and compact repeated returns to the left anchor.

    Anchor-localization residuals often contain repeated cycles that return to
    the preceding shared activity.  For example, after an anchor ``C`` a TRD
    block may contain ``P,M,Q,C,P,M,Q,C``.  Mining such blocks exactly creates
    many visually duplicated leaves.  When all non-empty blocks can be parsed as
    one or more cycles ending in the left anchor, this helper factors them into
    a compact loop whose body is ``local-behavior ; left-anchor``.  Otherwise it
    falls back to the ordinary miner.
    """

    if compact_return_cycles:
        compact = _try_compact_return_cycles(block_log, gap=gap, discovery_cfg=discovery_cfg)
        if compact is not None:
            return compact.simplified()

    return mine_process_tree(block_log, config=discovery_cfg).simplified()


def _try_compact_return_cycles(
    block_log: Sequence[Trace],
    *,
    gap: GapKey,
    discovery_cfg: DiscoveryConfig,
) -> ProcessTree | None:
    """Return a compact cycle model for residuals that revisit the left anchor.

    The transformation is conservative. It is applied only when every non-empty
    residual block ends at the left anchor and can be split into complete cycles
    of the form ``local segment ; left anchor``. Empty residual blocks, if
    present, are represented by an optional tau branch.
    """

    _, left_label, _ = gap
    if left_label in {"START", "END", "ROOT"}:
        return None

    traces = [tuple(trace) for trace in block_log]
    non_empty = [trace for trace in traces if trace]
    if not non_empty:
        return None

    # This compaction is meant for genuine return cycles, not for a single
    # ordinary residual activity accidentally equal to the anchor.
    if not any(left_label in trace for trace in non_empty):
        return None

    all_segments: list[Trace] = []
    cycle_counts: list[int] = []

    for trace in non_empty:
        segments = _split_complete_return_cycles(trace, left_label)
        if segments is None:
            return None
        cycle_counts.append(len(segments))
        all_segments.extend(segments)

    if not all_segments:
        return None

    segment_model = mine_process_tree(all_segments, config=discovery_cfg).simplified()
    anchor_leaf = ProcessTree.activity(left_label)
    if segment_model.op == TAU:
        cycle_body = anchor_leaf
    elif segment_model.op == SEQ:
        cycle_body = ProcessTree.operator(SEQ, [*segment_model.children, anchor_leaf])
    else:
        cycle_body = sequence_or_single([segment_model, anchor_leaf])

    # One cycle is enough for logs that return once; a loop compactly represents
    # traces with repeated returns to the same anchor.
    if max(cycle_counts, default=0) > 1:
        compact: ProcessTree = ProcessTree.operator(LOOP, [cycle_body, ProcessTree.tau()])
    else:
        compact = cycle_body

    if any(not trace for trace in traces):
        compact = ProcessTree.operator(XOR, [ProcessTree.tau(), compact])

    return compact.simplified()


def _split_complete_return_cycles(trace: Trace, marker: str) -> list[Trace] | None:
    """Split a trace into segments that are each immediately followed by marker.

    Returns ``None`` when the trace has events after the final marker or when it
    does not contain the marker at all. The marker itself is not included in the
    returned segments.
    """

    if not trace or marker not in trace or trace[-1] != marker:
        return None

    segments: list[Trace] = []
    current: list[str] = []
    for activity in trace:
        if activity == marker:
            segments.append(tuple(current))
            current = []
        else:
            current.append(activity)

    if current:
        return None
    return segments


def _activity_case_supports(
    log: VariantLog,
    variants: Sequence[str],
) -> dict[str, dict[str, float]]:
    """Compute case-level activity support for each variant.

    support_v(a) = number of cases in variant v that contain activity a
    divided by the number of cases in variant v. This activity-level evidence is
    used only for visualization annotations on CPST arcs.
    """

    case_counts = {variant: 0 for variant in variants}
    activity_case_counts: dict[str, dict[str, int]] = {
        variant: defaultdict(int) for variant in variants
    }

    for case in log.cases:
        case_counts[case.variant] += 1
        for activity in set(case.trace):
            activity_case_counts[case.variant][activity] += 1

    supports: dict[str, dict[str, float]] = {}
    for variant in variants:
        denominator = max(1, case_counts[variant])
        supports[variant] = {
            activity: count / denominator
            for activity, count in activity_case_counts[variant].items()
        }
    return supports


def _common_activities_from_cdfg(cdfg: CDFG) -> frozenset[str]:
    """Return activities retained as available in every C-DFG variant view.

    This keeps the shared-context construction aligned with C-DFG availability
    and pruning. It intentionally excludes synthetic lifecycle nodes.
    """

    all_variants = frozenset(cdfg.variants)
    return frozenset(
        activity
        for activity, availability in cdfg.node_availability.items()
        if activity not in {SOURCE, SINK}
        and activity in cdfg.activities
        and availability == all_variants
    )


def _shared_context_log(
    log: VariantLog,
    shared_activities: frozenset[str],
    *,
    collapse_repeated: bool,
) -> list[Trace]:
    traces = log.projected_traces(shared_activities, collapse_consecutive=False)
    if collapse_repeated:
        traces = [collapse_consecutive_duplicates(trace) for trace in traces]
    return [trace for trace in traces if trace]


def _structure_first_result(
    log: VariantLog,
    variants: Sequence[str],
    discovery_cfg: DiscoveryConfig,
    *,
    cdfg: CDFG,
    shared_activities: frozenset[str],
    shared_context: ProcessTree | None,
    activity_supports: Mapping[str, Mapping[str, float]],
    note: str,
) -> EnrichmentResult:
    tree = _structure_first_merge_tree(log, variants, discovery_cfg)
    return EnrichmentResult(
        cdfg=cdfg,
        shared_activities=shared_activities,
        shared_context=shared_context,
        tree=tree,
        fragments=tuple(),
        used_fallback=True,  # Backward-compatible legacy flag.
        construction_mode=CONSTRUCTION_STRUCTURE_FIRST_MERGE,
        construction_note=note,
        activity_supports=activity_supports,
    )


def _structure_first_merge_tree(log: VariantLog, variants: Sequence[str], discovery_cfg: DiscoveryConfig) -> ProcessTree:
    """Build a C-PST by mining one tree per variant and merging shared structure.

    This is a first-class construction path, not an error path.  It is used when
    the log does not support a reliable sequence anchor or when the mined shared
    context contains non-linear process-tree structure.
    """

    branches: list[ProcessTree] = []
    for variant in variants:
        subtree = _mine_structure_first_variant_tree(log.sublog(variant), discovery_cfg).simplified()
        subtree.set_variants_recursive({variant})
        branches.append(subtree)

    merged = _merge_variant_branches_recursively(branches, variants)
    return merged.simplified()


def _fallback_tree(log: VariantLog, variants: Sequence[str], discovery_cfg: DiscoveryConfig) -> ProcessTree:
    """Backward-compatible alias for the structure-first merge path."""

    return _structure_first_merge_tree(log, variants, discovery_cfg)


def _mine_structure_first_variant_tree(traces: Sequence[Trace], discovery_cfg: DiscoveryConfig) -> ProcessTree:
    """Mine one variant tree for the structure-first merge path.

    PM4Py's Inductive Miner is used when available, because it usually produces
    more meaningful high-level trees for real logs. If PM4Py is unavailable or
    cannot handle the input, the dependency-free miner remains available.
    """

    pm4py_tree = _try_mine_pm4py_tree(traces)
    if pm4py_tree is not None:
        return pm4py_tree.simplified()
    return mine_process_tree(traces, config=discovery_cfg).simplified()


def _try_mine_pm4py_tree(traces: Sequence[Trace]) -> ProcessTree | None:
    normalized = [tuple(str(activity) for activity in trace) for trace in traces]
    if not normalized:
        return ProcessTree.tau()

    if any(len(trace) == 0 for trace in normalized):
        return None

    try:
        import pandas as pd
        import pm4py
    except Exception:
        return None

    rows = []
    base_time = pd.Timestamp("2000-01-01")
    for case_index, trace in enumerate(normalized):
        for event_index, activity in enumerate(trace):
            rows.append(
                {
                    "case_id": f"c{case_index}",
                    "activity": activity,
                    "timestamp": base_time + pd.Timedelta(seconds=event_index),
                }
            )

    if not rows:
        return ProcessTree.tau()

    try:
        df = pd.DataFrame(rows)
        df = pm4py.format_dataframe(
            df,
            case_id="case_id",
            activity_key="activity",
            timestamp_key="timestamp",
        )
        mined = pm4py.discover_process_tree_inductive(df)
        return _convert_pm4py_process_tree(mined)
    except Exception:
        return None


def _convert_pm4py_process_tree(node) -> ProcessTree:
    label = getattr(node, "label", None)
    operator = getattr(node, "operator", None)
    children = list(getattr(node, "children", []) or [])

    if label is not None:
        return ProcessTree.activity(str(label))
    if operator is None:
        return ProcessTree.tau()

    op = _map_pm4py_operator(operator)
    converted = [_convert_pm4py_process_tree(child) for child in children]

    if op == LOOP:
        if len(converted) == 1:
            converted.append(ProcessTree.tau())
        if len(converted) < 2:
            return ProcessTree.tau()
        return ProcessTree.operator(LOOP, converted[:2])

    if not converted:
        return ProcessTree.tau()
    return ProcessTree.operator(op, converted).simplified()


def _map_pm4py_operator(operator) -> str:
    name = str(getattr(operator, "name", "")).lower()
    value = str(getattr(operator, "value", "")).lower()
    text = str(operator).lower()
    key = f"{name} {value} {text}"

    if "sequence" in key or "->" in key:
        return SEQ
    if "parallel" in key or "+" in key or "and" in key:
        return PAR
    if "xor" in key or text.strip() == "x":
        return XOR
    if "loop" in key or "*" in key:
        return LOOP

    return XOR


def _merge_variant_branches_recursively(
    branches: Sequence[ProcessTree],
    variants: Sequence[str],
) -> ProcessTree:
    """Recursively share identical structure and keep only residual differences."""

    if not branches:
        return ProcessTree.tau(variants=variants)

    signatures = [_structural_signature(branch) for branch in branches]
    if len(set(signatures)) == 1:
        shared = branches[0].clone()
        shared.set_variants_recursive(variants)
        return shared

    first_op = branches[0].op
    if not all(branch.op == first_op for branch in branches):
        return _variant_choice(branches, variants)

    if first_op in {PAR, XOR}:
        return _merge_unordered_operator(branches, variants, first_op)

    if first_op == SEQ:
        return _merge_sequence_operator(branches, variants)

    if first_op == LOOP and all(len(branch.children) == 2 for branch in branches):
        body = _merge_variant_branches_recursively([branch.children[0] for branch in branches], variants)
        redo = _merge_variant_branches_recursively([branch.children[1] for branch in branches], variants)
        return ProcessTree.operator(LOOP, [body, redo], variants=variants)

    return _variant_choice(branches, variants)


def _merge_unordered_operator(
    branches: Sequence[ProcessTree],
    variants: Sequence[str],
    op: str,
) -> ProcessTree:
    """Merge children of unordered operators across variants.

    Exact isomorphic subtrees are shared recursively. Unmatched residual regions
    remain variant-specific configurable alternatives, which avoids introducing
    behavior that was not supported by the per-variant trees.
    """

    child_lists = [[child.clone() for child in branch.children] for branch in branches]
    common_sigs = _common_child_signatures(child_lists)

    shared_children: list[ProcessTree] = []
    for sig in common_sigs:
        matched = [_pop_child_with_signature(children, sig) for children in child_lists]
        shared_children.append(_merge_variant_branches_recursively(matched, variants))

    # Keep unsupported residual differences as configurable alternatives.
    # Earlier versions generalized same-activity residuals into a shared
    # order-agnostic block; that preserved coverage but could enlarge the
    # configured language. The paper-level guarantee is now implemented
    # conservatively: share exact/recursively safe structure and leave the rest
    # variant-specific.
    residuals: list[ProcessTree] = []
    for variant, remaining in zip(variants, child_lists):
        if remaining:
            residuals.append(_operator_or_single(op, remaining, {variant}))
        else:
            residuals.append(ProcessTree.tau(variants={variant}))
    children = [*shared_children]
    if any(tree.op != TAU for tree in residuals):
        children.append(_variant_choice(residuals, variants))

    if not children:
        return ProcessTree.tau(variants=variants)
    if len(children) == 1:
        # Preserve child activation sets.  A single child may already be a
        # configurable choice with variant-specific branches; rewriting all
        # descendants to the parent variants would destroy the configuration.
        child = children[0].clone()
        if child.variants is None:
            child.set_variants_recursive(variants)
        return child
    return ProcessTree.operator(op, children, variants=variants)


def _merge_sequence_operator(branches: Sequence[ProcessTree], variants: Sequence[str]) -> ProcessTree:
    """Merge sequence operators while preserving configured behavior.

    Common prefix/suffix structure is shared recursively. Remaining middle
    regions are kept as variant-specific configurable alternatives unless they
    can be shared through exact recursive structure.
    """

    child_lists = [[child.clone() for child in branch.children] for branch in branches]

    prefix: list[ProcessTree] = []
    while all(child_lists) and len({_structural_signature(children[0]) for children in child_lists}) == 1:
        matched = [children.pop(0) for children in child_lists]
        prefix.append(_merge_variant_branches_recursively(matched, variants))

    suffix_reversed: list[ProcessTree] = []
    while all(child_lists) and len({_structural_signature(children[-1]) for children in child_lists}) == 1:
        matched = [children.pop() for children in child_lists]
        suffix_reversed.append(_merge_variant_branches_recursively(matched, variants))

    children = [*prefix]

    # Keep unsupported middle-region differences as configurable alternatives
    # instead of generalizing same-activity residuals into a broader language.
    residuals: list[ProcessTree] = []
    for variant, remaining in zip(variants, child_lists):
        if remaining:
            residuals.append(sequence_or_single(remaining, variants={variant}))
        else:
            residuals.append(ProcessTree.tau(variants={variant}))
    if any(tree.op != TAU for tree in residuals):
        children.append(_variant_choice(residuals, variants))

    children.extend(reversed(suffix_reversed))
    if not children:
        return ProcessTree.tau(variants=variants)
    if len(children) == 1:
        # Preserve labels of a single configurable child, e.g., a variant choice.
        child = children[0].clone()
        if child.variants is None:
            child.set_variants_recursive(variants)
        return child
    return ProcessTree.operator(SEQ, children, variants=variants)


def _variant_choice(branches: Sequence[ProcessTree], variants: Sequence[str]) -> ProcessTree:
    if len(branches) != len(variants):
        raise ValueError("variant-choice construction needs one branch per variant")

    alternatives: list[ProcessTree] = []
    for variant, branch in zip(variants, branches):
        alternative = branch.clone()
        alternative.set_variants_recursive({variant})
        alternatives.append(alternative)

    if not alternatives:
        return ProcessTree.tau(variants=variants)
    if len(alternatives) == 1:
        return alternatives[0]
    return ProcessTree.operator(XOR, alternatives, variants=variants)


def _operator_or_single(op: str, children: Sequence[ProcessTree], variants: set[str] | frozenset[str]) -> ProcessTree:
    if not children:
        return ProcessTree.tau(variants=variants)
    if len(children) == 1:
        child = children[0].clone()
        child.set_variants_recursive(variants)
        return child
    if op == SEQ:
        return sequence_or_single(children, variants=variants)
    return ProcessTree.operator(op, [child.clone() for child in children], variants=variants)


def _common_child_signatures(child_lists: Sequence[Sequence[ProcessTree]]) -> list:
    counters = [Counter(_structural_signature(child) for child in children) for children in child_lists]
    used: Counter = Counter()
    common: list = []

    for child in child_lists[0]:
        sig = _structural_signature(child)
        if all(counter[sig] > used[sig] for counter in counters):
            common.append(sig)
            used[sig] += 1
    return common


def _pop_child_with_signature(children: list[ProcessTree], signature) -> ProcessTree:
    for index, child in enumerate(children):
        if _structural_signature(child) == signature:
            return children.pop(index)
    raise ValueError("internal error: common child signature disappeared")


def _structural_signature(tree: ProcessTree):
    child_sigs = [_structural_signature(child) for child in tree.children]
    if tree.op in {PAR, XOR}:
        child_sigs = sorted(child_sigs, key=repr)
    return (tree.op, tree.label, tuple(child_sigs))


def _collect_residual_fragment_logs(
    log: VariantLog,
    anchor_sequence: Sequence[str],
) -> dict[tuple[str, GapKey], list[Trace]]:
    """Collect residual blocks for every trace and every anchor gap.

    The anchor alignment is an earliest LCS-style alignment against the shared
    context's canonical sequence. Events not consumed by the anchor are residuals.
    Empty residuals are kept so that the fragment miner can learn optionality.
    """

    output: dict[tuple[str, GapKey], list[Trace]] = defaultdict(list)
    for case in log.cases:
        matched_positions = _earliest_subsequence_match(case.trace, tuple(anchor_sequence))
        if matched_positions is None:
            # If the anchor cannot be matched, treat the entire trace as a root
            # residual. This is conservative and keeps coverage possible.
            gap = (-1, "ROOT", "ROOT")
            output[(case.variant, gap)].append(case.trace)
            continue

        boundaries = [-1, *matched_positions, len(case.trace)]
        for gap_index in range(len(boundaries) - 1):
            start = boundaries[gap_index] + 1
            end = boundaries[gap_index + 1]
            block = tuple(case.trace[start:end])
            left_label = "START" if gap_index == 0 else anchor_sequence[gap_index - 1]
            right_label = "END" if gap_index == len(anchor_sequence) else anchor_sequence[gap_index]
            gap = (gap_index, left_label, right_label)
            output[(case.variant, gap)].append(block)
    return output


def _earliest_subsequence_match(trace: Sequence[str], pattern: Sequence[str]) -> tuple[int, ...] | None:
    positions: list[int] = []
    pos = 0
    for wanted in pattern:
        found = False
        while pos < len(trace):
            if trace[pos] == wanted:
                positions.append(pos)
                pos += 1
                found = True
                break
            pos += 1
        if not found:
            return None
    return tuple(positions)


def _anchor_sequence_is_supported(log: VariantLog, anchor_sequence: Sequence[str]) -> bool:
    """Return whether the canonical anchor can be aligned to every case.

    Residual localization is meaningful only when the shared anchor is actually
    observed as a subsequence in each trace.  This guard prevents non-sequential
    or overfitted shared contexts from being flattened into a long artificial
    sequence and then silently losing all variant-specific residual behavior.
    """

    if not anchor_sequence:
        return False
    return all(
        _earliest_subsequence_match(case.trace, tuple(anchor_sequence)) is not None
        for case in log.cases
    )


def _insert_fragments_into_sequence_context(
    shared_tree: ProcessTree,
    anchor_sequence: Sequence[str],
    fragments: Sequence[ResidualFragment],
    variants: Sequence[str],
) -> ProcessTree:
    """Insert residual fragments around the shared context.

    Fragments are placed into the corresponding gaps of an executable sequence
    anchor. Non-linear shared contexts are handled by the structure-first merge
    path before this function is called.
    """

    fragments_by_gap: dict[int, list[ResidualFragment]] = defaultdict(list)
    for fragment in fragments:
        fragments_by_gap[fragment.gap[0]].append(fragment)

    root_fragments = fragments_by_gap.pop(-1, [])

    # Use the actual root sequence children when it exactly matches the anchor;
    # otherwise use activity leaves in the canonical order as a safe sequence.
    if shared_tree.op == SEQ and tuple(shared_tree.canonical_sequence()) == tuple(anchor_sequence):
        anchor_nodes = [child.clone() for child in shared_tree.children]
    else:
        anchor_nodes = [ProcessTree.activity(activity, variants=variants) for activity in anchor_sequence]

    children: list[ProcessTree] = []
    for gap_index in range(len(anchor_nodes) + 1):
        for fragment in fragments_by_gap.get(gap_index, []):
            children.append(fragment.tree.clone())
        if gap_index < len(anchor_nodes):
            children.append(anchor_nodes[gap_index])

    anchored_root = sequence_or_single(children, variants=variants)

    if root_fragments:
        root_alternatives = [fragment.tree.clone() for fragment in root_fragments]
        if any(fragments_by_gap.values()):
            root_alternatives.append(anchored_root)
        root = ProcessTree.operator(XOR, root_alternatives, variants=variants)
    else:
        root = anchored_root

    root.set_variants_recursive_for_missing(variants) if hasattr(root, "set_variants_recursive_for_missing") else None
    _fill_missing_variants(root, frozenset(variants))
    return root.simplified()


def _fill_missing_variants(tree: ProcessTree, default_variants: frozenset[str]) -> None:
    if tree.variants is None:
        tree.variants = default_variants
    for child in tree.children:
        _fill_missing_variants(child, tree.variants if tree.variants is not None else default_variants)
