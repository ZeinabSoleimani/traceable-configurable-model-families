from __future__ import annotations

from dataclasses import dataclass, field
import itertools
import json
from typing import Any, Iterable, Sequence

TAU = "tau"
ACT = "act"
SEQ = "seq"
XOR = "xor"
PAR = "and"
LOOP = "loop"

_OPERATOR_SYMBOLS = {SEQ: "→", XOR: "×", PAR: "∧", LOOP: "↺"}


@dataclass
class ProcessTree:
    """Process tree with optional data-derived activation labels.

    ``op`` is one of ``act``, ``tau``, ``seq``, ``xor``, ``and``, or ``loop``.
    For activity leaves, ``label`` stores the activity name. ``variants`` stores
    the activation set. ``None`` means unconstrained during intermediate mining;
    enrichment assigns explicit activation sets.
    """

    op: str
    label: str | None = None
    children: list["ProcessTree"] = field(default_factory=list)
    variants: frozenset[str] | None = None
    meta: dict[str, Any] = field(default_factory=dict)

    @staticmethod
    def activity(label: str, variants: Iterable[str] | None = None) -> "ProcessTree":
        return ProcessTree(ACT, label=label, variants=_variant_set(variants))

    @staticmethod
    def tau(variants: Iterable[str] | None = None) -> "ProcessTree":
        return ProcessTree(TAU, variants=_variant_set(variants))

    @staticmethod
    def operator(
        op: str,
        children: Sequence["ProcessTree"],
        variants: Iterable[str] | None = None,
        **meta: Any,
    ) -> "ProcessTree":
        if op not in {SEQ, XOR, PAR, LOOP}:
            raise ValueError(f"unknown operator: {op}")
        if op == LOOP and len(children) != 2:
            raise ValueError("loop nodes require exactly body and redo children")
        if op != LOOP and len(children) < 1:
            raise ValueError(f"{op} nodes require at least one child")
        return ProcessTree(op, children=list(children), variants=_variant_set(variants), meta=dict(meta))

    @property
    def is_leaf(self) -> bool:
        return self.op in {ACT, TAU}

    def clone(self) -> "ProcessTree":
        return ProcessTree(
            op=self.op,
            label=self.label,
            children=[child.clone() for child in self.children],
            variants=self.variants,
            meta=dict(self.meta),
        )

    def with_variants_recursive(self, variants: Iterable[str]) -> "ProcessTree":
        variant_set = frozenset(variants)
        cloned = self.clone()
        for node in cloned.walk():
            node.variants = variant_set
        return cloned

    def set_variants_recursive(self, variants: Iterable[str]) -> None:
        variant_set = frozenset(variants)
        for node in self.walk():
            node.variants = variant_set

    def walk(self) -> Iterable["ProcessTree"]:
        yield self
        for child in self.children:
            yield from child.walk()

    def activities(self) -> frozenset[str]:
        return frozenset(node.label for node in self.walk() if node.op == ACT and node.label is not None)

    def visible_leaf_count(self) -> int:
        return sum(1 for node in self.walk() if node.op == ACT)

    def canonical_sequence(self) -> tuple[str, ...]:
        """Return a deterministic visible leaf order used for residual localization.

        For sequence nodes this is the sequence order. For choices and parallel
        nodes, children are traversed in stored order. This is a localization aid,
        not a full language characterization.
        """

        if self.op == ACT:
            return (self.label,) if self.label is not None else tuple()
        if self.op == TAU:
            return tuple()
        values: list[str] = []
        for child in self.children:
            values.extend(child.canonical_sequence())
        return tuple(values)

    def project(self, variant: str) -> "ProcessTree":
        """Configure the tree for one variant and simplify inactive nodes.

        Inactive configuration branches are removed from their parent instead of
        being materialized as ``tau`` branches. This is important for XOR nodes:
        a variant-specific alternative that is inactive for the selected variant
        must disappear, otherwise projection would introduce artificial optional
        behavior. Explicit tau leaves that are active for the variant are still
        preserved, so true optional behavior mined from the log remains intact.
        """

        projected = self._project_or_none(variant)
        if projected is None:
            return ProcessTree.tau(variants={variant})
        return projected.simplified()

    def _project_or_none(self, variant: str) -> "ProcessTree | None":
        """Project this subtree, returning ``None`` for inactive subtrees."""

        if self.variants is not None and variant not in self.variants:
            return None
        if self.op == ACT:
            return ProcessTree.activity(self.label or "", variants={variant})
        if self.op == TAU:
            return ProcessTree.tau(variants={variant})

        if self.op == LOOP:
            projected_by_position = [child._project_or_none(variant) for child in self.children]
            body = projected_by_position[0] if projected_by_position else None
            redo = (
                projected_by_position[1]
                if len(projected_by_position) > 1 and projected_by_position[1] is not None
                else ProcessTree.tau(variants={variant})
            )
            if body is None:
                return ProcessTree.tau(variants={variant})
            return ProcessTree.operator(LOOP, [body, redo], variants={variant}, **self.meta)

        projected_children = [
            projected
            for child in self.children
            if (projected := child._project_or_none(variant)) is not None
        ]
        if not projected_children:
            return ProcessTree.tau(variants={variant})
        return ProcessTree.operator(self.op, projected_children, variants={variant}, **self.meta)

    def simplified(self) -> "ProcessTree":
        if self.is_leaf:
            return self.clone()
        children = [child.simplified() for child in self.children]
        if self.op in {SEQ, PAR}:
            children = [child for child in children if child.op != TAU]
            if not children:
                return ProcessTree.tau(variants=self.variants)
            if len(children) == 1:
                return children[0]
            return ProcessTree.operator(self.op, children, variants=self.variants, **self.meta)
        if self.op == XOR:
            # Keep one tau child to preserve optional behavior if it exists.
            tau_children = [child for child in children if child.op == TAU]
            visible_children = [child for child in children if child.op != TAU]
            if not visible_children:
                return ProcessTree.tau(variants=self.variants)
            if tau_children:
                children = [ProcessTree.tau(variants=self.variants), *visible_children]
            else:
                children = visible_children
            if len(children) == 1:
                return children[0]
            return ProcessTree.operator(XOR, children, variants=self.variants, **self.meta)
        if self.op == LOOP:
            body = children[0] if children else ProcessTree.tau(variants=self.variants)
            redo = children[1] if len(children) > 1 else ProcessTree.tau(variants=self.variants)
            if body.op == TAU:
                # A tau body would be unsound as a process-tree loop. Fall back
                # to tau instead of constructing an invalid configured view.
                return ProcessTree.tau(variants=self.variants)
            return ProcessTree.operator(LOOP, [body, redo], variants=self.variants, **self.meta)
        raise ValueError(f"unknown operator: {self.op}")

    def is_well_formed(self) -> bool:
        """Check the activation-set well-formedness used in the paper."""

        if self.is_leaf:
            return True
        if self.variants is None:
            return all(child.is_well_formed() for child in self.children)
        for child in self.children:
            if child.variants is not None and not child.variants.issubset(self.variants):
                return False
        for variant in self.variants:
            if not any(child.variants is None or variant in child.variants for child in self.children):
                return False
        if self.op == LOOP:
            body = self.children[0]
            for variant in self.variants:
                if body.variants is not None and variant not in body.variants:
                    return False
                if body.projects_to_empty(variant):
                    return False
        return all(child.is_well_formed() for child in self.children)

    def projects_to_empty(self, variant: str) -> bool:
        projected = self.project(variant)
        return projected.op == TAU

    def accepts_observed_trace(self, trace: Sequence[str], *, max_loop_depth: int = 2) -> bool:
        """Return whether the tree can replay an observed trace.

        This direct parser avoids enumerating the full bounded language, which
        becomes infeasible for parallel trees with many optional/repeated
        branches. For observed-trace coverage, loops are unfolded up to at least
        the trace length so repeated observed activities are not rejected only
        because the default loop bound was too small.
        """

        trace_tuple = tuple(trace)
        effective_loop_depth = max(max_loop_depth, len(trace_tuple))
        return _accept_trace(self, trace_tuple, max_loop_depth=effective_loop_depth)


    def enumerate_language(self, *, max_loop_depth: int = 2, max_traces: int = 10_000) -> frozenset[tuple[str, ...]]:
        traces = _enumerate(self, max_loop_depth=max_loop_depth, max_traces=max_traces)
        return frozenset(itertools.islice(traces, max_traces))

    def to_dict(self) -> dict[str, Any]:
        return {
            "op": self.op,
            "label": self.label,
            "variants": sorted(self.variants) if self.variants is not None else None,
            "meta": self.meta,
            "children": [child.to_dict() for child in self.children],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ProcessTree":
        return ProcessTree(
            op=data["op"],
            label=data.get("label"),
            variants=frozenset(data["variants"]) if data.get("variants") is not None else None,
            meta=dict(data.get("meta") or {}),
            children=[cls.from_dict(child) for child in data.get("children", [])],
        )

    def to_json(self, *, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)

    def to_text(self, *, show_variants: bool = True) -> str:
        if self.op == ACT:
            base = self.label or ""
        elif self.op == TAU:
            base = "τ"
        else:
            symbol = _OPERATOR_SYMBOLS[self.op]
            base = f"{symbol}(" + ", ".join(child.to_text(show_variants=show_variants) for child in self.children) + ")"
        if show_variants and self.variants is not None:
            return f"{base}^{{{','.join(sorted(self.variants))}}}"
        return base

    def to_dot(self) -> str:
        """Return Graphviz DOT text."""

        lines = ["digraph ProcessTree {", "  node [shape=box];"]
        counter = itertools.count()

        def visit(node: ProcessTree) -> int:
            idx = next(counter)
            if node.op == ACT:
                label = node.label or ""
            elif node.op == TAU:
                label = "τ"
            else:
                label = _OPERATOR_SYMBOLS[node.op]
            if node.variants is not None:
                label = f"{label}\\n[{', '.join(sorted(node.variants))}]"
            lines.append(f'  n{idx} [label="{label}"];')
            for child in node.children:
                child_idx = visit(child)
                lines.append(f"  n{idx} -> n{child_idx};")
            return idx

        visit(self)
        lines.append("}")
        return "\n".join(lines)

    def __str__(self) -> str:
        return self.to_text(show_variants=True)


def _variant_set(variants: Iterable[str] | None) -> frozenset[str] | None:
    if variants is None:
        return None
    return frozenset(variants)


def sequence_or_single(children: Sequence[ProcessTree], variants: Iterable[str] | None = None) -> ProcessTree:
    cleaned = [child for child in children if child.op != TAU]
    if not cleaned:
        return ProcessTree.tau(variants=variants)
    if len(cleaned) == 1:
        child = cleaned[0].clone()
        if variants is not None:
            child.set_variants_recursive(variants)
        return child
    return ProcessTree.operator(SEQ, cleaned, variants=variants)


def xor_or_single(children: Sequence[ProcessTree], variants: Iterable[str] | None = None) -> ProcessTree:
    if not children:
        return ProcessTree.tau(variants=variants)
    if len(children) == 1:
        child = children[0].clone()
        if variants is not None:
            child.set_variants_recursive(variants)
        return child
    return ProcessTree.operator(XOR, list(children), variants=variants)




def _accept_trace(tree: ProcessTree, trace: tuple[str, ...], *, max_loop_depth: int) -> bool:
    """Direct bounded membership check for a process tree."""

    from functools import lru_cache

    node_ids = {id(node): node for node in tree.walk()}

    @lru_cache(maxsize=None)
    def accepts(node_id: int, subtrace: tuple[str, ...]) -> bool:
        node = node_ids[node_id]

        if node.op == ACT:
            return len(subtrace) == 1 and subtrace[0] == node.label

        if node.op == TAU:
            return len(subtrace) == 0

        if node.op == XOR:
            return any(accepts(id(child), subtrace) for child in node.children)

        if node.op == SEQ:
            return accepts_sequence(tuple(id(child) for child in node.children), subtrace)

        if node.op == PAR:
            return accepts_parallel(tuple(id(child) for child in node.children), subtrace)

        if node.op == LOOP:
            return accepts_loop(id(node.children[0]), id(node.children[1]), subtrace)

        raise ValueError(f"unknown operator: {node.op}")

    @lru_cache(maxsize=None)
    def accepts_sequence(child_ids: tuple[int, ...], subtrace: tuple[str, ...]) -> bool:
        positions = {0}

        for child_id in child_ids:
            new_positions: set[int] = set()

            for start in positions:
                for end in range(start, len(subtrace) + 1):
                    if accepts(child_id, subtrace[start:end]):
                        new_positions.add(end)

            if not new_positions:
                return False

            positions = new_positions

        return len(subtrace) in positions

    @lru_cache(maxsize=None)
    def accepts_loop(body_id: int, redo_id: int, subtrace: tuple[str, ...]) -> bool:
        # Process-tree loop language: body (redo body)^k, k >= 0.
        for depth in range(max_loop_depth + 1):
            sequence = [body_id]
            for _ in range(depth):
                sequence.extend([redo_id, body_id])

            if accepts_sequence(tuple(sequence), subtrace):
                return True

        return False

    @lru_cache(maxsize=None)
    def accepts_parallel(child_ids: tuple[int, ...], subtrace: tuple[str, ...]) -> bool:
        if not child_ids:
            return len(subtrace) == 0

        children = [node_ids[child_id] for child_id in child_ids]
        activity_sets = [child.activities() for child in children]
        visible_sets = [acts for acts in activity_sets if acts]
        union = frozenset().union(*visible_sets) if visible_sets else frozenset()

        if any(activity not in union for activity in subtrace):
            return False

        # Exact fast path: if parallel branches have disjoint alphabets, each
        # event belongs to one branch and we only need to check projections.
        seen: set[str] = set()
        disjoint = True
        for acts in activity_sets:
            overlap = seen & set(acts)
            if overlap:
                disjoint = False
                break
            seen.update(acts)

        if disjoint:
            for child_id, acts in zip(child_ids, activity_sets):
                projected = tuple(activity for activity in subtrace if activity in acts)
                if not accepts(child_id, projected):
                    return False
            return True

        # Conservative fallback for small overlapping alphabets.
        if len(subtrace) > 30 or len(child_ids) > 8:
            return False

        initial = tuple(() for _ in child_ids)

        @lru_cache(maxsize=None)
        def assign(pos: int, buffers: tuple[tuple[str, ...], ...]) -> bool:
            if pos == len(subtrace):
                return all(
                    accepts(child_id, buffers[i])
                    for i, child_id in enumerate(child_ids)
                )

            activity = subtrace[pos]
            for i, acts in enumerate(activity_sets):
                if activity in acts:
                    updated = list(buffers)
                    updated[i] = updated[i] + (activity,)
                    if assign(pos + 1, tuple(updated)):
                        return True

            return False

        return assign(0, initial)

    return accepts(id(tree), trace)


def _enumerate(tree: ProcessTree, *, max_loop_depth: int, max_traces: int) -> Iterable[tuple[str, ...]]:
    if tree.op == ACT:
        yield (tree.label,) if tree.label is not None else tuple()
        return
    if tree.op == TAU:
        yield tuple()
        return
    if tree.op == XOR:
        yielded = 0
        for child in tree.children:
            for trace in _enumerate(child, max_loop_depth=max_loop_depth, max_traces=max_traces):
                yield trace
                yielded += 1
                if yielded >= max_traces:
                    return
        return
    if tree.op == SEQ:
        traces: list[tuple[str, ...]] = [tuple()]
        for child in tree.children:
            child_traces = list(_enumerate(child, max_loop_depth=max_loop_depth, max_traces=max_traces))
            traces = [left + right for left in traces for right in child_traces]
            if len(traces) > max_traces:
                traces = traces[:max_traces]
        yield from traces
        return
    if tree.op == PAR:
        child_langs = [list(_enumerate(child, max_loop_depth=max_loop_depth, max_traces=max_traces)) for child in tree.children]
        yielded = 0
        for combo in itertools.product(*child_langs):
            for trace in _all_interleavings(combo):
                yield trace
                yielded += 1
                if yielded >= max_traces:
                    return
        return
    if tree.op == LOOP:
        body_lang = list(_enumerate(tree.children[0], max_loop_depth=max_loop_depth, max_traces=max_traces))
        redo_lang = list(_enumerate(tree.children[1], max_loop_depth=max_loop_depth, max_traces=max_traces))
        yielded = 0
        for depth in range(max_loop_depth + 1):
            for body in body_lang:
                traces = [body]
                for _ in range(depth):
                    traces = [prefix + redo + body for prefix in traces for redo in redo_lang for body in body_lang]
                for trace in traces:
                    yield trace
                    yielded += 1
                    if yielded >= max_traces:
                        return
        return
    raise ValueError(f"unknown operator: {tree.op}")


def _all_interleavings(parts: Sequence[tuple[str, ...]]) -> Iterable[tuple[str, ...]]:
    if not parts:
        yield tuple()
        return
    if len(parts) == 1:
        yield parts[0]
        return
    first, *rest = parts
    for tail in _all_interleavings(rest):
        yield from _interleave_two(first, tail)


def _interleave_two(a: tuple[str, ...], b: tuple[str, ...]) -> Iterable[tuple[str, ...]]:
    if not a:
        yield b
    elif not b:
        yield a
    else:
        for tail in _interleave_two(a[1:], b):
            yield (a[0],) + tail
        for tail in _interleave_two(a, b[1:]):
            yield (b[0],) + tail
