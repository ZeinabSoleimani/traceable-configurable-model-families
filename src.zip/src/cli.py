from __future__ import annotations

import argparse
from pathlib import Path
import sys

from .data import VariantLog, depression_example_log
from .enrichment import EnrichmentConfig, enrich_process_tree
from .io import write_result
from .metrics import observed_trace_coverage, residual_relation_localization


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="evidence-cpt")
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run", help="enrich a variant-labeled log")
    run.add_argument("--input", required=True, help="CSV input path")
    run.add_argument("--format", choices=["trace", "event"], default="trace")
    run.add_argument("--out", required=True, help="output directory")
    run.add_argument("--case-col", default="case_id")
    run.add_argument("--variant-col", default="variant")
    run.add_argument("--trace-col", default="trace")
    run.add_argument("--trace-sep", default=",")
    run.add_argument("--activity-col", default="activity")
    run.add_argument("--timestamp-col", default="timestamp")
    _add_method_args(run)

    ex = sub.add_parser("example", help="run the built-in example log")
    ex.add_argument("--out", required=True, help="output directory")
    _add_method_args(ex)

    args = parser.parse_args(argv)
    if args.command == "run":
        if args.format == "trace":
            log = VariantLog.from_trace_csv(
                args.input,
                case_col=args.case_col,
                variant_col=args.variant_col,
                trace_col=args.trace_col,
                trace_sep=args.trace_sep,
            )
        else:
            log = VariantLog.from_event_csv(
                args.input,
                case_col=args.case_col,
                variant_col=args.variant_col,
                activity_col=args.activity_col,
                timestamp_col=args.timestamp_col,
            )
        return _run(log, args)
    if args.command == "example":
        return _run(depression_example_log(), args)
    parser.error("unknown command")
    return 2


def _add_method_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--theta", type=float, default=0.0)
    parser.add_argument("--alpha", type=float, default=0.05)
    parser.add_argument("--n-min", type=int, default=5)
    parser.add_argument("--min-shared-activities", type=int, default=2)
    parser.add_argument(
        "--no-collapse-repeated-shared-activities",
        action="store_true",
        help="do not collapse consecutive repetitions in shared-context projections",
    )
    parser.add_argument(
        "--no-compact-return-cycles",
        action="store_true",
        help=(
            "disable residual return-cycle compaction; keeps exact localized "
            "residual fragments, which can be visually repetitive"
        ),
    )
    parser.add_argument(
        "--coverage-check",
        action="store_true",
        help="run a small finite-language observed-trace coverage check",
    )
    parser.add_argument(
        "--no-render",
        action="store_true",
        help="write DOT/CSV/JSON outputs but skip SVG/PNG rendering",
    )
    parser.add_argument(
        "--cdfg-core-min-support",
        type=float,
        default=0.10,
        help="minimum max variant support for keeping an edge in cdfg_core visualization",
    )
    parser.add_argument(
        "--cdfg-core-min-support-delta",
        type=float,
        default=0.05,
        help="minimum support difference between variants for keeping an edge in cdfg_core visualization",
    )
    parser.add_argument(
        "--cdfg-core-min-support-by-variant",
        type=str,
        default=None,
        help=(
            "variant-specific support thresholds for cdfg_core visualization, "
            "for example: variantA=0.20,variantB=0.10"
        ),
    )
    parser.add_argument(
        "--cdfg-core-dominance-only",
        action="store_true",
        help="keep only dominant/differential edges in cdfg_core, plus lifecycle edges",
    )
    parser.add_argument(
        "--cpst-show-tau",
        action="store_true",
        help=(
            "show trivial silent τ leaves in default CPST DOT views; "
            "JSON/TXT outputs always keep the original tree semantics"
        ),
    )
    parser.add_argument(
        "--cpst-tiny-support-threshold",
        type=float,
        default=0.01,
        help="show positive support values below this threshold as <threshold instead of 0.00",
    )
    parser.add_argument(
        "--no-cpst-core",
        action="store_true",
        help="do not write the compact configurable_tree_core DOT view",
    )
    


def _parse_variant_thresholds(value: str | None) -> dict[str, float] | None:
    if value is None or not value.strip():
        return None

    thresholds: dict[str, float] = {}

    for item in value.split(","):
        item = item.strip()
        if not item:
            continue

        if "=" not in item:
            raise ValueError(
                "Invalid --cdfg-core-min-support-by-variant format. "
                "Use something like: variantA=0.20,variantB=0.10"
            )

        variant, threshold = item.split("=", 1)
        variant = variant.strip()
        threshold = threshold.strip()

        if not variant:
            raise ValueError("Variant name cannot be empty.")

        thresholds[variant] = float(threshold)

    return thresholds

def _run(log: VariantLog, args: argparse.Namespace) -> int:
    cfg = EnrichmentConfig(
        theta=args.theta,
        alpha=args.alpha,
        n_min=args.n_min,
        min_shared_activities=args.min_shared_activities,
        collapse_repeated_shared_activities=not args.no_collapse_repeated_shared_activities,
        compact_return_cycles=not args.no_compact_return_cycles,
    )
    result = enrich_process_tree(log, config=cfg)
    cdfg_core_min_support_by_variant = _parse_variant_thresholds(
        args.cdfg_core_min_support_by_variant
    )
    write_result(
        result,
        args.out,
        render_visuals=not args.no_render,
        cdfg_core_min_support=args.cdfg_core_min_support,
        cdfg_core_min_support_delta=args.cdfg_core_min_support_delta,
        cdfg_core_min_support_by_variant=cdfg_core_min_support_by_variant,
        cdfg_core_dominance_only=args.cdfg_core_dominance_only,
        cpst_hide_trivial_tau=not args.cpst_show_tau,
        cpst_tiny_support_threshold=args.cpst_tiny_support_threshold,
        write_cpst_core=not args.no_cpst_core,
    )

    print(f"variants: {', '.join(log.variants)}")
    print(f"shared activities: {', '.join(sorted(result.shared_activities)) or '<none>'}")
    print(f"construction mode: {result.construction_mode}")
    if result.construction_note:
        print(f"construction note: {result.construction_note}")
    print(f"fallback flag (legacy): {result.used_fallback}")
    print(f"fragments: {len(result.fragments)}")
    print(f"wrote: {Path(args.out).resolve()}")

    if result.construction_mode != "anchor_localization" or not result.fragments:
        print(
            "residual localization proxy: n/a "
            "(defined only for anchor-localization runs with localized residual fragments; "
            "structure-first merge represents differences through recursive CPST merging and CDFG evidence)"
        )
    else:
        loc = residual_relation_localization(result)
        print(
            "residual localization proxy: "
            f"precision={loc.precision:.3f}, recall={loc.recall:.3f}, f1={loc.f1:.3f} "
            f"(tp={loc.true_positive}, fp={loc.false_positive}, fn={loc.false_negative})"
        )
    if args.coverage_check:
        for report in observed_trace_coverage(log, result.tree):
            print(
                f"coverage[{report.variant}]: {report.covered}/{report.total} "
                f"({report.fitness_proxy:.3f})"
            )
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
